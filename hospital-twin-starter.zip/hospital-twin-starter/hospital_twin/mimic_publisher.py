"""
hospital_twin/mimic_publisher.py
=================================
Task 2: MIMIC-IV telemetry ingestion and NEWS2 priority scoring node.

Publishes real ICU vital-sign data replayed from the MIMIC-IV dataset
to /patient/{id}/vitals (PatientVitals) and /patient/{id}/priority (Float32).

References
----------
MIMIC-IV: https://physionet.org/content/mimiciv/3.1/
NEWS2:    https://www.rcplondon.ac.uk/projects/outputs/national-early-warning-score-news-2
"""

import rclpy
import pandas as pd
import numpy as np
from rclpy.node import Node
from std_msgs.msg import Float32, String
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy

# Custom message — built via hospital_twin_msgs package
from hospital_twin_msgs.msg import PatientVitals

from .news2_scorer import news2_score, ewma_priority


class MimicPublisher(Node):
    """Replays MIMIC-IV ICU vitals and publishes NEWS2-based patient priorities.

    Parameters (ROS 2 parameters)
    ------------------------------
    csv_path      : str   — path to mimic_vitals_sample.csv
    replay_speed  : float — multiplier (1.0 = real-time, 10.0 = 10× faster)
    tick_rate_hz  : float — how often to publish a new reading (default 1.0)
    ewma_alpha    : float — EWMA smoothing coefficient for priority (default 0.3)
    """

    def __init__(self) -> None:
        super().__init__("mimic_publisher")

        # ── Declare ROS 2 parameters ──────────────────────────────────────────
        self.declare_parameter("csv_path", "data/mimic_vitals_sample.csv")
        self.declare_parameter("replay_speed", 1.0)
        self.declare_parameter("tick_rate_hz", 1.0)
        self.declare_parameter("ewma_alpha", 0.3)

        csv_path = self.get_parameter("csv_path").value
        self.replay_speed = self.get_parameter("replay_speed").value
        self.alpha = self.get_parameter("ewma_alpha").value
        tick_hz = self.get_parameter("tick_rate_hz").value

        # ── Load dataset ──────────────────────────────────────────────────────
        self.get_logger().info(f"Loading vitals from: {csv_path}")
        self.df = pd.read_csv(csv_path)
        self._validate_columns()

        # ── State ─────────────────────────────────────────────────────────────
        self.patient_ids: list[str] = self.df["subject_id"].astype(str).unique().tolist()
        self.news2_history: dict[str, list[float]] = {pid: [] for pid in self.patient_ids}
        self.row_index: dict[str, int] = {pid: 0 for pid in self.patient_ids}

        # ── Publishers (one per patient) ──────────────────────────────────────
        qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            history=HistoryPolicy.KEEP_LAST,
            depth=10,
        )
        self.vitals_pubs: dict[str, rclpy.publisher.Publisher] = {}
        self.priority_pubs: dict[str, rclpy.publisher.Publisher] = {}

        # TODO Task 2: Uncomment and complete the publisher creation loop
        # for pid in self.patient_ids:
        #     self.vitals_pubs[pid]   = self.create_publisher(
        #         PatientVitals, f"/patient/{pid}/vitals", qos)
        #     self.priority_pubs[pid] = self.create_publisher(
        #         Float32, f"/patient/{pid}/priority", qos)

        self.get_logger().warning(
            "TODO (Task 2): Publisher loop not yet implemented. "
            "Uncomment the loop above."
        )

        # ── Timer ─────────────────────────────────────────────────────────────
        period = 1.0 / tick_hz
        self.timer = self.create_timer(period, self._tick)
        self.get_logger().info(
            f"MimicPublisher started: {len(self.patient_ids)} patients, "
            f"tick={tick_hz:.1f} Hz, speed={self.replay_speed}×"
        )

    # ── Private helpers ────────────────────────────────────────────────────────

    def _validate_columns(self) -> None:
        """Raise ValueError if required columns are missing from the CSV."""
        required = {"subject_id", "heart_rate", "spo2", "resp_rate", "sbp", "dbp"}
        missing = required - set(self.df.columns)
        if missing:
            raise ValueError(
                f"CSV missing required columns: {missing}. "
                f"Available: {list(self.df.columns)}"
            )

    def _get_patient_row(self, pid: str) -> pd.Series | None:
        """Return the next row for a given patient, cycling through rows.

        Returns None if the patient has no data.
        """
        patient_df = self.df[self.df["subject_id"].astype(str) == pid]
        if patient_df.empty:
            return None
        idx = self.row_index[pid] % len(patient_df)
        self.row_index[pid] += 1
        return patient_df.iloc[idx]

    def _build_vitals_msg(self, pid: str, row: pd.Series) -> PatientVitals:
        """Construct a PatientVitals message from a DataFrame row.

        Handles NaN values by substituting sentinel -1.0 (indicating missing).
        """
        msg = PatientVitals()
        msg.patient_id = pid
        msg.stamp = self.get_clock().now().to_msg()

        def safe_float(val: object, sentinel: float = -1.0) -> float:
            """Return float or sentinel if NaN/missing."""
            try:
                f = float(val)
                return sentinel if np.isnan(f) else f
            except (TypeError, ValueError):
                return sentinel

        msg.heart_rate  = safe_float(row.get("heart_rate"))
        msg.spo2        = safe_float(row.get("spo2"))
        msg.resp_rate   = safe_float(row.get("resp_rate"))
        msg.systolic_bp = safe_float(row.get("sbp"))
        msg.diastolic_bp = safe_float(row.get("dbp"))
        msg.temperature = safe_float(row.get("temperature", -1.0))

        return msg

    def _compute_priority(self, pid: str, msg: PatientVitals) -> float:
        """Compute EWMA NEWS2 priority score for one patient.

        TODO Task 2: Replace the stub below with a call to news2_score()
        and ewma_priority(). Return the EWMA score (higher = more urgent).
        """
        # ── STUB (replace this) ───────────────────────────────────────────────
        score = 0.0  # TODO: score, _ = news2_score(msg.heart_rate, ...)
        self.news2_history[pid].append(score)
        priority = ewma_priority(self.news2_history[pid], alpha=self.alpha)
        return priority

    # ── Timer callback ─────────────────────────────────────────────────────────

    def _tick(self) -> None:
        """Called at tick_rate_hz. Publishes vitals and priority for every patient."""
        for pid in self.patient_ids:
            row = self._get_patient_row(pid)
            if row is None:
                continue

            msg = self._build_vitals_msg(pid, row)

            # TODO Task 2: publish msg on self.vitals_pubs[pid]
            # self.vitals_pubs[pid].publish(msg)

            priority = self._compute_priority(pid, msg)
            pri_msg = Float32()
            pri_msg.data = float(priority)

            # TODO Task 2: publish pri_msg on self.priority_pubs[pid]
            # self.priority_pubs[pid].publish(pri_msg)

            self.get_logger().debug(
                f"Patient {pid}: HR={msg.heart_rate:.0f} SpO2={msg.spo2:.0f} "
                f"priority={priority:.2f}"
            )


def main(args=None) -> None:
    rclpy.init(args=args)
    node = MimicPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
