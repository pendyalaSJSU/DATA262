"""
launch/full_system.launch.py
==============================
Task 5: Single launch file that starts the complete hospital digital twin system.

Usage
-----
  # After building: colcon build && source install/setup.bash
  ros2 launch hospital_twin full_system.launch.py

  # With custom parameters:
  ros2 launch hospital_twin full_system.launch.py \
      num_patients:=5 \
      replay_speed:=5.0 \
      use_rl_policy:=true

Nodes started
-------------
  1. mimic_publisher      — MIMIC-IV telemetry + NEWS2 priority scoring
  2. delivery_planner     — Nav2 priority-aware delivery dispatcher
  3. nav2_bringup         — Full Nav2 navigation stack
  4. system_monitor       — RViz2/Foxglove dashboard
  5. isaac_ros_bridge     — Isaac Sim ↔ ROS 2 sensor bridge (if Isaac Sim running)
  6. foxglove_bridge      — WebSocket bridge for Foxglove Studio

NOTE for Task 5: The TODO markers below indicate what you must implement.
The Isaac Sim instance itself must be started manually via the Omniverse Launcher
before running this launch file.
"""

from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    IncludeLaunchDescription,
    LogInfo,
    TimerAction,
)
from launch.conditions import IfCondition, UnlessCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import (
    LaunchConfiguration,
    PathJoinSubstitution,
    PythonExpression,
)
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
import os


def generate_launch_description():

    # ── Launch arguments ──────────────────────────────────────────────────────
    # TODO Task 5: Add any additional arguments you need.
    args = [
        DeclareLaunchArgument(
            "num_patients", default_value="5",
            description="Number of patients to simulate"),
        DeclareLaunchArgument(
            "replay_speed", default_value="1.0",
            description="MIMIC-IV replay speed multiplier"),
        DeclareLaunchArgument(
            "use_rl_policy", default_value="false",
            description="Use Isaac Lab RL policy instead of Nav2 DWB planner"),
        DeclareLaunchArgument(
            "use_foxglove", default_value="true",
            description="Start Foxglove WebSocket bridge"),
        DeclareLaunchArgument(
            "rviz", default_value="true",
            description="Start RViz2"),
        DeclareLaunchArgument(
            "map", default_value=PathJoinSubstitution([
                FindPackageShare("hospital_twin"), "maps", "hospital_ward.yaml"
            ]),
            description="Nav2 map file"),
        DeclareLaunchArgument(
            "params_file", default_value=PathJoinSubstitution([
                FindPackageShare("hospital_twin"), "config", "nav2_params.yaml"
            ]),
            description="Nav2 parameters file"),
    ]

    # ── Node 1: MIMIC-IV telemetry publisher ──────────────────────────────────
    mimic_node = Node(
        package="hospital_twin",
        executable="mimic_publisher",
        name="mimic_publisher",
        output="screen",
        parameters=[{
            "csv_path": PathJoinSubstitution([
                FindPackageShare("hospital_twin"), "data", "mimic_vitals_sample.csv"
            ]),
            "replay_speed": LaunchConfiguration("replay_speed"),
            "tick_rate_hz": 1.0,
            "ewma_alpha": 0.3,
        }],
    )

    # ── Node 2: Delivery planner ──────────────────────────────────────────────
    # TODO Task 5: Uncomment and configure the delivery planner node.
    # delivery_node = Node(
    #     package="hospital_twin",
    #     executable="delivery_planner",
    #     name="delivery_planner",
    #     output="screen",
    #     parameters=[{
    #         "room_map_path": PathJoinSubstitution([
    #             FindPackageShare("hospital_twin"), "data", "patient_room_map.json"
    #         ]),
    #         "preemption_threshold": 3.0,
    #         "delivery_timeout_s": 120.0,
    #     }],
    # )

    # ── Node 3: Nav2 stack ────────────────────────────────────────────────────
    # TODO Task 5: Include the Nav2 bringup launch file.
    # The pre-built config is in config/nav2_params.yaml.
    # nav2_launch = IncludeLaunchDescription(
    #     PythonLaunchDescriptionSource([
    #         FindPackageShare("nav2_bringup"), "/launch/bringup_launch.py"
    #     ]),
    #     launch_arguments={
    #         "map": LaunchConfiguration("map"),
    #         "params_file": LaunchConfiguration("params_file"),
    #         "use_sim_time": "true",
    #     }.items(),
    # )

    # ── Node 4: System monitor / RViz2 ───────────────────────────────────────
    rviz_node = Node(
        package="rviz2",
        executable="rviz2",
        name="rviz2",
        arguments=["-d", PathJoinSubstitution([
            FindPackageShare("hospital_twin"), "config", "rviz2_hospital.rviz"
        ])],
        condition=IfCondition(LaunchConfiguration("rviz")),
        output="screen",
    )

    # ── Node 5: Foxglove WebSocket bridge ────────────────────────────────────
    # TODO Task 5: Uncomment the Foxglove bridge node.
    # Connects Foxglove Studio at ws://localhost:8765
    # foxglove_node = Node(
    #     package="foxglove_bridge",
    #     executable="foxglove_bridge",
    #     name="foxglove_bridge",
    #     parameters=[{"port": 8765, "address": "0.0.0.0"}],
    #     condition=IfCondition(LaunchConfiguration("use_foxglove")),
    #     output="screen",
    # )

    # ── Startup log ───────────────────────────────────────────────────────────
    startup_log = LogInfo(
        msg=(
            "\n"
            "╔══════════════════════════════════════════════╗\n"
            "║   Hospital Digital Twin — Embodied AI Course ║\n"
            "╠══════════════════════════════════════════════╣\n"
            "║ Isaac Sim: start manually via Omniverse      ║\n"
            "║ ROS 2 topics: ros2 topic list                ║\n"
            "║ Foxglove:    ws://localhost:8765             ║\n"
            "║ Stop:        Ctrl-C                          ║\n"
            "╚══════════════════════════════════════════════╝\n"
        )
    )

    return LaunchDescription([
        *args,
        startup_log,
        mimic_node,
        # TODO Task 5: add delivery_node, nav2_launch, foxglove_node below
        # delivery_node,
        # nav2_launch,
        # foxglove_node,
        rviz_node,
    ])
