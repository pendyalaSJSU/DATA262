"""
tests/test_mimic_publisher.py
==============================
Unit tests for the MimicPublisher node (no ROS 2 runtime required).

Tests the data loading, sentinel handling, and message construction
by instantiating the relevant helper methods directly.

Run: pytest tests/test_mimic_publisher.py -v
"""

import io
import sys
import os
import pytest
import pandas as pd
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# We test the pure-Python helpers without starting the ROS 2 node
# by importing the module and monkey-patching rclpy.
sys.modules.setdefault("rclpy", type(sys)("rclpy"))
sys.modules.setdefault("rclpy.node", type(sys)("rclpy.node"))
sys.modules.setdefault("rclpy.qos", type(sys)("rclpy.qos"))
sys.modules.setdefault("hospital_twin_msgs", type(sys)("hospital_twin_msgs"))
sys.modules.setdefault("hospital_twin_msgs.msg", type(sys)("hospital_twin_msgs.msg"))
sys.modules.setdefault("std_msgs", type(sys)("std_msgs"))
sys.modules.setdefault("std_msgs.msg", type(sys)("std_msgs.msg"))

from hospital_twin.news2_scorer import ewma_priority, news2_score


# ── Sample data fixture ────────────────────────────────────────────────────────

@pytest.fixture
def sample_csv(tmp_path):
    """Create a minimal synthetic MIMIC-like CSV for testing."""
    rows = []
    for pid in ["p001", "p002"]:
        for i in range(10):
            rows.append({
                "subject_id": pid,
                "charttime":  f"2024-01-01 00:{i*5:02d}:00",
                "heart_rate": 70 + i,
                "spo2":       98 - i * 0.2,
                "resp_rate":  14 + i * 0.1,
                "sbp":        120 - i,
                "dbp":        80,
                "temperature": 37.0,
            })
    df = pd.DataFrame(rows)
    path = tmp_path / "test_vitals.csv"
    df.to_csv(path, index=False)
    return str(path), df


# ── CSV loading ────────────────────────────────────────────────────────────────

class TestCSVLoading:
    def test_csv_loads(self, sample_csv):
        path, df = sample_csv
        loaded = pd.read_csv(path)
        assert len(loaded) == 20
        assert "subject_id" in loaded.columns

    def test_required_columns_present(self, sample_csv):
        path, _ = sample_csv
        df = pd.read_csv(path)
        required = {"subject_id", "heart_rate", "spo2", "resp_rate", "sbp"}
        assert required.issubset(set(df.columns))

    def test_patient_ids_extracted(self, sample_csv):
        path, _ = sample_csv
        df = pd.read_csv(path)
        pids = df["subject_id"].astype(str).unique().tolist()
        assert set(pids) == {"p001", "p002"}

    def test_missing_column_raises(self, tmp_path):
        bad_csv = tmp_path / "bad.csv"
        pd.DataFrame({"subject_id": ["p001"], "heart_rate": [70]}).to_csv(bad_csv)
        df = pd.read_csv(bad_csv)
        required = {"subject_id", "heart_rate", "spo2", "resp_rate", "sbp"}
        missing = required - set(df.columns)
        assert "spo2" in missing


# ── Sentinel handling ──────────────────────────────────────────────────────────

class TestSentinelHandling:
    """Verify that NaN / missing values are safely handled."""

    def _safe_float(self, val, sentinel=-1.0):
        """Replicate the safe_float helper from MimicPublisher."""
        try:
            f = float(val)
            return sentinel if np.isnan(f) else f
        except (TypeError, ValueError):
            return sentinel

    def test_nan_returns_sentinel(self):
        assert self._safe_float(float("nan")) == -1.0

    def test_none_returns_sentinel(self):
        assert self._safe_float(None) == -1.0

    def test_valid_float_passes(self):
        assert self._safe_float(72.5) == pytest.approx(72.5)

    def test_string_sentinel(self):
        assert self._safe_float("no data") == -1.0

    def test_zero_is_not_sentinel(self):
        """Zero is a valid physiological value (e.g. temp offset), not a sentinel."""
        assert self._safe_float(0.0) == pytest.approx(0.0)


# ── NEWS2 integration (via scorer) ────────────────────────────────────────────

class TestNEWS2Integration:
    """Verify that vitals from the sample CSV produce plausible NEWS2 scores."""

    def test_stable_patient_low_risk(self):
        """Typical stable patient values should score 0 (low risk)."""
        score, risk = news2_score(
            heart_rate=72, resp_rate=14, spo2=98,
            systolic_bp=125, temperature=37.0, avpu="A"
        )
        assert score == 0
        assert risk == "low"

    def test_sentinel_values_dont_crash(self):
        """Calling news2_score with sentinel -1.0 should not raise."""
        score, risk = news2_score(
            heart_rate=-1.0, resp_rate=14, spo2=97,
            systolic_bp=-1.0
        )
        assert isinstance(score, int)

    def test_ewma_increases_with_deterioration(self):
        """Priority EWMA should rise as NEWS2 scores increase over time."""
        stable_scores      = [0, 0, 0, 0, 1]
        deteriorating      = [0, 2, 4, 6, 9]
        stable_priority    = ewma_priority(stable_scores)
        deteriorating_priority = ewma_priority(deteriorating)
        assert deteriorating_priority > stable_priority


# ── Patient isolation ─────────────────────────────────────────────────────────

class TestPatientIsolation:
    """Verify that patient data streams are independent."""

    def test_row_index_per_patient(self, sample_csv):
        path, df = sample_csv
        # Simulate independent per-patient row indices
        patient_ids = df["subject_id"].astype(str).unique().tolist()
        row_index = {pid: 0 for pid in patient_ids}

        def get_next(pid):
            sub = df[df["subject_id"].astype(str) == pid]
            idx = row_index[pid] % len(sub)
            row_index[pid] += 1
            return sub.iloc[idx]

        # Advance p001 5 times
        for _ in range(5):
            get_next("p001")

        # p002 should still be at its first row
        row = get_next("p002")
        assert row["subject_id"] == "p002"
        # p001 should be at row 5
        row2 = get_next("p001")
        assert row2["subject_id"] == "p001"
