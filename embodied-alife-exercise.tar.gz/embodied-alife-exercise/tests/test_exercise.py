"""
Test suite for the Embodied ALife Exercise.
Run with: pytest tests/ -v

Each test corresponds to a graded deliverable.
Students should NOT modify this file.
Green = passing, Red = not yet implemented.
"""

import pytest
import numpy as np
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

try:
    import mujoco
    MUJOCO_AVAILABLE = True
except ImportError:
    MUJOCO_AVAILABLE = False

from environment import (
    QuadrupedMorphology,
    CPGController,
    TerrainGenerator,
    EvolutionaryOptimizer,
)


# ===========================================================================
# PART 1: Morphogenesis Tests
# ===========================================================================

class TestMorphology:

    def test_default_genome_valid(self):
        """Genome should have all required keys with positive values."""
        morph = QuadrupedMorphology()
        required_keys = [
            "torso_size", "upper_leg_len", "lower_leg_len",
            "leg_radius", "leg_spread", "mass_torso",
            "gear_hip", "gear_knee"
        ]
        for key in required_keys:
            assert key in morph.genome, f"Missing genome key: {key}"
            assert morph.genome[key] > 0, f"Genome key {key} must be positive"

    def test_build_xml_returns_string(self):
        """build_xml() must return a non-empty string."""
        morph = QuadrupedMorphology()
        xml = morph.build_xml()
        assert isinstance(xml, str), "build_xml() must return a string"
        assert len(xml) > 100, "XML string suspiciously short"

    @pytest.mark.skipif(not MUJOCO_AVAILABLE, reason="MuJoCo not installed")
    def test_xml_loads_in_mujoco(self):
        """Generated XML must be parseable by MuJoCo without errors."""
        morph = QuadrupedMorphology()
        xml = morph.build_xml()
        try:
            model = mujoco.MjModel.from_xml_string(xml)
        except Exception as e:
            pytest.fail(f"MuJoCo failed to load generated XML: {e}")
        assert model.nq > 0, "Model should have DOFs"

    @pytest.mark.skipif(not MUJOCO_AVAILABLE, reason="MuJoCo not installed")
    def test_required_sensors_present(self):
        """Model must have touch, IMU, and rangefinder sensors."""
        morph = QuadrupedMorphology()
        xml = morph.build_xml()
        model = mujoco.MjModel.from_xml_string(xml)
        
        sensor_names = [
            mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_SENSOR, i)
            for i in range(model.nsensor)
        ]
        
        # Must have 4 touch sensors
        touch_sensors = [s for s in sensor_names if "touch" in s.lower()]
        assert len(touch_sensors) >= 4, f"Need 4 touch sensors, got {len(touch_sensors)}"
        
        # Must have rangefinder(s)
        range_sensors = [s for s in sensor_names if "range" in s.lower()]
        assert len(range_sensors) >= 1, "Need at least 1 rangefinder sensor"

    @pytest.mark.skipif(not MUJOCO_AVAILABLE, reason="MuJoCo not installed")
    def test_correct_actuator_count(self):
        """Model should have exactly 12 actuators (3 per leg × 4 legs)."""
        morph = QuadrupedMorphology()
        xml = morph.build_xml()
        model = mujoco.MjModel.from_xml_string(xml)
        assert model.nu == 12, f"Expected 12 actuators, got {model.nu}"

    def test_mutate_returns_new_morphology(self):
        """Mutate should return a different morphology object."""
        morph = QuadrupedMorphology()
        mutant = morph.mutate(sigma=0.1)
        assert isinstance(mutant, QuadrupedMorphology)
        # Genomes should differ
        assert mutant.genome != morph.genome, "Mutation produced identical genome"

    def test_mutate_stays_valid(self):
        """Mutated genome parameters should remain positive."""
        morph = QuadrupedMorphology()
        for _ in range(20):  # test many mutations
            mutant = morph.mutate(sigma=0.2)
            for key, val in mutant.genome.items():
                assert val > 0, f"Mutation produced invalid (non-positive) {key}={val}"

    def test_genome_affects_model_size(self):
        """Changing genome should change physical dimensions."""
        morph_small = QuadrupedMorphology({"upper_leg_len": 0.10, "lower_leg_len": 0.08})
        morph_large = QuadrupedMorphology({"upper_leg_len": 0.30, "lower_leg_len": 0.28})
        xml_small = morph_small.build_xml()
        xml_large = morph_large.build_xml()
        # XMLs should differ
        assert xml_small != xml_large, "Different genomes produced identical XML"


# ===========================================================================
# PART 2: CPG Controller Tests
# ===========================================================================

class TestCPG:

    def test_step_returns_correct_shape(self):
        """CPG step should return (8,) joint target array."""
        cpg = CPGController()
        dummy_sensors = {
            "touch":   np.zeros(4),
            "gyro":    np.zeros(3),
            "acc":     np.array([0, 0, 9.81]),
            "rangefwd": 2.0,
            "rangedn":  0.4,
        }
        targets = cpg.step(dummy_sensors)
        assert targets.shape == (8,), f"Expected shape (8,), got {targets.shape}"

    def test_step_targets_bounded(self):
        """Joint targets should be within joint limits (-π/2 to π/2 range)."""
        cpg = CPGController(amplitude=0.6)
        dummy = {"touch": np.zeros(4), "gyro": np.zeros(3),
                 "acc": np.array([0,0,9.81]), "rangefwd": 2.0, "rangedn": 0.4}
        for _ in range(200):
            targets = cpg.step(dummy)
            assert np.all(np.abs(targets) < 2.0), "Targets out of bounds"

    def test_oscillation_is_periodic(self):
        """CPG should produce periodic output (autocorrelation peak at ~1/freq)."""
        cpg = CPGController(base_frequency=2.0, dt=0.002)
        dummy = {"touch": np.zeros(4), "gyro": np.zeros(3),
                 "acc": np.array([0,0,9.81]), "rangefwd": 2.0, "rangedn": 0.4}
        
        history = []
        for _ in range(2000):  # 4 seconds
            history.append(cpg.step(dummy)[0])  # track first joint
        
        history = np.array(history)
        # Signal should have nonzero variance (oscillating)
        assert history.std() > 0.05, "CPG output is not oscillating"
        
        # Autocorrelation should show periodicity
        autocorr = np.correlate(history - history.mean(),
                                history - history.mean(), mode='full')
        autocorr = autocorr[len(autocorr)//2:]
        # Expected period ~ 1/2Hz * 500steps/sec = 250 steps
        peaks = np.where((autocorr[1:-1] > autocorr[:-2]) &
                         (autocorr[1:-1] > autocorr[2:]))[0] + 1
        if len(peaks) > 0:
            period = peaks[0]
            assert 150 < period < 400, f"Period {period} steps not near expected ~250"

    def test_gait_switch_works(self):
        """Switching gaits should not crash and should change coupling."""
        cpg = CPGController(gait="trot")
        old_coupling = cpg.coupling.copy()
        cpg.switch_gait("walk")
        assert not np.allclose(cpg.coupling, old_coupling), \
            "Switching gaits did not change coupling matrix"

    def test_metabolic_cost_positive(self):
        """Metabolic cost should be non-negative."""
        cpg = CPGController()
        torques = np.random.randn(8) * 5
        velocities = np.random.randn(8) * 2
        cost = cpg.get_metabolic_cost(torques, velocities)
        assert cost >= 0, f"Metabolic cost must be non-negative, got {cost}"

    def test_stumble_reflex_modulates_amplitude(self):
        """High unexpected contact should increase amplitude modulation."""
        cpg = CPGController()
        # No contact → baseline modulation (all ~1.0)
        low_contact = np.zeros(4)
        high_contact = np.array([50.0, 0.0, 0.0, 0.0])  # RF leg stumbles
        
        mod_low  = cpg.stumble_reflex(low_contact)
        mod_high = cpg.stumble_reflex(high_contact)
        
        assert mod_low.shape  == (4,), "Modulation must be shape (4,)"
        assert mod_high.shape == (4,), "Modulation must be shape (4,)"
        # RF leg should respond
        assert mod_high[0] != mod_low[0], "Stumble reflex did not respond to contact"


# ===========================================================================
# PART 3: Terrain Generator Tests
# ===========================================================================

class TestTerrain:

    def test_flat_terrain_is_zeros(self):
        gen = TerrainGenerator(size=(32, 32))
        h = gen.generate("flat")
        assert h.shape == (32, 32)
        assert np.allclose(h, 0), "Flat terrain should be all zeros"

    def test_rubble_terrain_has_variation(self):
        gen = TerrainGenerator(size=(64, 64))
        h = gen.generate("rubble", seed=42)
        assert h.shape == (64, 64)
        assert h.dtype == np.float32
        assert h.std() > 0.01, "Rubble terrain should have height variation"
        assert 0 <= h.min() and h.max() <= 1, "Heights must be in [0,1]"

    def test_terrain_reproducible(self):
        gen = TerrainGenerator(size=(32, 32))
        h1 = gen.generate("rubble", seed=99)
        h2 = gen.generate("rubble", seed=99)
        assert np.allclose(h1, h2), "Same seed must produce identical terrain"

    def test_different_seeds_differ(self):
        gen = TerrainGenerator(size=(32, 32))
        h1 = gen.generate("rubble", seed=1)
        h2 = gen.generate("rubble", seed=2)
        assert not np.allclose(h1, h2), "Different seeds should produce different terrain"

    def test_unknown_terrain_raises(self):
        gen = TerrainGenerator()
        with pytest.raises(ValueError):
            gen.generate("moon_surface")

    def test_embed_in_xml_produces_valid_xml(self):
        """embed_in_xml should return string containing height data."""
        import xml.etree.ElementTree as ET
        gen = TerrainGenerator(size=(64, 64))
        h = gen.generate("flat")
        
        # Load starter XML
        xml_path = Path(__file__).parent.parent / "configs" / "quadruped_starter.xml"
        with open(xml_path) as f:
            xml_str = f.read()
        
        result = gen.embed_in_xml(xml_str, h)
        assert isinstance(result, str)
        # Should be parseable XML
        try:
            ET.fromstring(result)
        except ET.ParseError as e:
            pytest.fail(f"embed_in_xml produced invalid XML: {e}")


# ===========================================================================
# PART 4: Evolutionary Optimizer Tests
# ===========================================================================

class TestEvolution:

    @pytest.mark.skipif(not MUJOCO_AVAILABLE, reason="MuJoCo not installed")
    def test_evaluate_individual_returns_metrics(self):
        """evaluate_individual must return dict with required keys."""
        morph = QuadrupedMorphology()
        cpg   = CPGController()
        terrain = TerrainGenerator(size=(32,32)).generate("flat")
        opt   = EvolutionaryOptimizer(episode_duration=1.0)
        
        metrics = opt.evaluate_individual(morph, cpg, terrain, render=False)
        
        required = ["fitness", "distance", "efficiency", "fell", "gait_stability"]
        for key in required:
            assert key in metrics, f"Missing metric: {key}"
        
        assert isinstance(metrics["fitness"], float)
        assert isinstance(metrics["fell"], bool)
        assert metrics["distance"] >= 0

    @pytest.mark.skipif(not MUJOCO_AVAILABLE, reason="MuJoCo not installed")
    def test_fitness_improves_over_generations(self):
        """
        Running evolution should trend toward higher fitness.
        NOTE: This is stochastic — test uses loose criterion.
        """
        opt = EvolutionaryOptimizer(
            population_size=5,
            n_generations=5,
            episode_duration=2.0,
        )
        results = opt.evolve()
        
        assert "best_fitness" in results
        assert "history" in results
        assert len(results["history"]) == 5
        
        # First gen fitness should be reasonable (robot doesn't fall immediately)
        first_fit = results["history"][0].get("best_fitness", 0)
        assert first_fit >= 0, "Initial fitness should be non-negative"


# ===========================================================================
# PART 6: Analysis Tests
# ===========================================================================

class TestAnalysis:
    
    def test_fitness_curve_saves_file(self, tmp_path):
        """plot_fitness_curve should save a PNG file."""
        from environment import ExperimentAnalyzer
        analyzer = ExperimentAnalyzer(results_dir=str(tmp_path))
        
        fake_history = [
            {"best_fitness": float(i*0.1), "mean_fitness": float(i*0.05),
             "std_fitness": 0.02}
            for i in range(10)
        ]
        analyzer.plot_fitness_curve(fake_history)
        
        saved = list(tmp_path.glob("*.png"))
        assert len(saved) > 0, "plot_fitness_curve should save a PNG"

    def test_gait_diagram_saves_file(self, tmp_path):
        """plot_gait_diagram should save a PNG file."""
        from environment import ExperimentAnalyzer
        analyzer = ExperimentAnalyzer(results_dir=str(tmp_path))
        
        # 4 feet × 500 timesteps, binary contact pattern
        contacts = (np.random.rand(4, 500) > 0.5).astype(float)
        analyzer.plot_gait_diagram(contacts, dt=0.002)
        
        saved = list(tmp_path.glob("*.png"))
        assert len(saved) > 0, "plot_gait_diagram should save a PNG"


# ===========================================================================
# Integration Test
# ===========================================================================

@pytest.mark.skipif(not MUJOCO_AVAILABLE, reason="MuJoCo not installed")
def test_full_pipeline_smoke():
    """
    Smoke test: entire pipeline runs without crashing.
    Uses minimal settings (1 gen, 2 offspring, 1 sec episodes).
    """
    # Terrain
    terrain = TerrainGenerator(size=(32, 32)).generate("flat")
    
    # Morphology
    morph = QuadrupedMorphology()
    xml = morph.build_xml()
    assert len(xml) > 0
    
    # CPG
    cpg = CPGController()
    
    # Short evaluation
    opt = EvolutionaryOptimizer(
        population_size=2,
        n_generations=1,
        episode_duration=1.0,
    )
    metrics = opt.evaluate_individual(morph, cpg, terrain, render=False)
    assert "fitness" in metrics
    
    print(f"\n✓ Smoke test passed. Fitness: {metrics['fitness']:.4f}, "
          f"Distance: {metrics['distance']:.3f}m, Fell: {metrics['fell']}")
