# NEWS2 Scoring Reference

**National Early Warning Score 2 (NEWS2)**  
Source: Royal College of Physicians, UK  
Spec: https://www.rcplondon.ac.uk/projects/outputs/national-early-warning-score-news-2

---

## Scoring Table

| Parameter | Score 3 | Score 2 | Score 1 | Score 0 | Score 1 | Score 2 | Score 3 |
|---|---|---|---|---|---|---|---|
| Respiratory rate (breaths/min) | ≤8 | — | 9–11 | 12–20 | — | 21–24 | ≥25 |
| SpO₂ scale 1 (%) | ≤91 | 92–93 | 94–95 | ≥96 | — | — | — |
| SpO₂ scale 2 (on O₂, %) | ≤83 | 84–85 | 86–87 | 88–92 | 93–94 | 95–96 | ≥97 |
| Systolic BP (mmHg) | ≤90 | 91–100 | 101–110 | 111–219 | — | — | ≥220 |
| Heart rate (beats/min) | ≤40 | — | 41–50 | 51–90 | 91–110 | 111–130 | ≥131 |
| Temperature (°C) | ≤35.0 | — | 35.1–36.0 | 36.1–38.0 | 38.1–39.0 | — | ≥39.1 |
| Level of consciousness (AVPU) | — | — | — | Alert (A) | — | — | Confusion/V/P/U |

> **Scale 2** is used for patients with hypercapnic respiratory failure (e.g. COPD)
> where the target SpO₂ range is 88–92%.

---

## Risk Stratification

| Aggregate Score | Clinical Risk | Response |
|---|---|---|
| 0 | Low | Minimum 12-hourly observations |
| 1–4 | Low | Minimum 4–6 hourly observations |
| 3 in any one parameter | Low–Medium | Increase frequency + inform nurse in charge |
| 5–6 | Medium | Urgent review by doctor |
| 7+ | High | **Emergency response** — immediate assessment |

---

## AVPU Scale

| Code | Meaning |
|---|---|
| A | Alert — patient is fully awake |
| C | New Confusion — new onset confusion (scores 3) |
| V | Voice — responds to voice (scores 3) |
| P | Pain — responds to pain only (scores 3) |
| U | Unresponsive (scores 3) |

---

## Implementation Notes for Task 2

1. **Missing values:** In MIMIC-IV, not all parameters are always charted. Use a sentinel
   value of `-1.0` in the `PatientVitals` message to indicate a missing reading. Do NOT
   score a missing parameter — treat it as 0 to avoid false alarms.

2. **EWMA smoothing:** A single abnormal reading may be noise. Use EWMA (alpha=0.3) to
   smooth over the last N readings before computing priority:
   ```
   ewma_t = alpha * score_t + (1 - alpha) * ewma_{t-1}
   ```

3. **Priority mapping:** Map EWMA score to a priority float in [0, 10] for the delivery
   planner. A score ≥7 should immediately flag the patient as urgent.

4. **Scale 2 detection:** Use the `on_oxygen` field in `PatientVitals`. If `True`, use
   SpO₂ scale 2. In MIMIC-IV, check `chartevents` for itemid 223835 (O2 delivery device).

---

## References

- Royal College of Physicians: https://www.rcplondon.ac.uk/projects/outputs/national-early-warning-score-news-2
- NICE guideline NG45: https://www.nice.org.uk/guidance/ng45
- NHS England deteriorating patient: https://www.england.nhs.uk/patient-safety/deteriorating-patient/
- MIMIC-IV chartevents: https://mimic.mit.edu/docs/iv/modules/icu/chartevents/
