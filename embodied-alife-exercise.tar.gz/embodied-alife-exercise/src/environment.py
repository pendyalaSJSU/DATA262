"""
====================================================================
EMBODIED AI EXERCISE: Morphogenetic Adaptation in Disaster Response
====================================================================
Course: Embodied AI  |  Module: Artificial Life & Morphological Computation
Author: [YOUR NAME]  |  Date: [DATE]

SCENARIO
--------
You are designing an ALife-inspired quadruped robot that must navigate
rubble-strewn disaster zones. Inspired by biological creatures that adapt
locomotion strategies to terrain (salamanders, cockroaches, crabs),
your agent must:
  1. Evolve a viable gait from scratch using evolutionary strategies
  2. Adapt its morphology (limb proportions) through a growth process
  3. Maintain homeostasis (energy budget) across varied terrain
  4. Exhibit emergent collective behavior when multiple agents co-exist

ALife concepts exercised:
  - Morphological computation (the body does the computing)
  - Evolutionary robotics (co-evolution of body + controller)
  - Sensorimotor loops & embodied cognition
  - Homeostasis & energy-aware behavior
  - Emergence from local rules

MuJoCo features exercised:
  - Custom XML model building at runtime (procedural morphogenesis)
  - Tendon actuation and contact dynamics
  - Sensor arrays (touch, IMU, rangefinder)
  - Terrain generation via heightfield
  - Multiple simultaneous agents (mjModel cloning)
  - Callbacks: mjcb_control for decentralized CPG controllers

References:
  - Sims (1994): Evolving Virtual Creatures
  - Brooks (1991): Intelligence Without Representation
  - Ijspeert (2008): Central Pattern Generators
  - Pfeifer & Bongard (2006): How the Body Shapes the Way We Think
"""

import numpy as np
import mujoco
import mujoco.viewer
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Optional, Tuple, Dict, List
import time

# ---------------------------------------------------------------------------
# PART 1 — Procedural Morphogenesis
# ---------------------------------------------------------------------------

class QuadrupedMorphology:
    """
    Builds a MuJoCo XML model programmatically, allowing limb parameters
    to be varied — mimicking biological growth / morphogenetic processes.

    ALife Connection: In ALife, morphology is NOT fixed. Sims (1994) showed
    that co-evolving body structure WITH neural controllers produces far
    richer, more adaptive behaviors than optimizing controllers alone.
    The body becomes part of the computation (morphological computation).

    TODO (Part 1a): Implement `build_xml` to generate valid MuJoCo XML
    TODO (Part 1b): Add a sensor suite (touch sensors on feet, IMU on torso,
                    rangefinders pointing forward/down)
    TODO (Part 1c): Implement `mutate` for evolutionary variation
    """

    # Genome: evolvable parameters defining the body plan
    DEFAULT_GENOME = {
        "torso_size":     0.25,   # half-size of torso box
        "upper_leg_len":  0.18,   # femur length
        "lower_leg_len":  0.16,   # tibia length
        "leg_radius":     0.025,  # leg cylinder radius
        "leg_spread":     0.20,   # lateral offset from torso center
        "mass_torso":     3.0,    # kg
        "gear_hip":       80.0,   # motor strength at hip
        "gear_knee":      60.0,   # motor strength at knee
    }

    def __init__(self, genome: Optional[Dict] = None):
        self.genome = {**self.DEFAULT_GENOME, **(genome or {})}
        self.xml_string: Optional[str] = None

    def build_xml(self) -> str:
        """
        Construct a MuJoCo XML string for the quadruped from self.genome.

        Requirements:
          - 4 legs, each with hip (2-DOF: abduction + flexion) and knee (1-DOF)
          - Touch sensors on each foot pad  (site → touch sensor)
          - Framequat + gyro sensors on torso (simulating IMU)
          - At least 2 rangefinder sensors (forward-looking, downward-looking)
          - Actuators using 'motor' type with gears from genome

        Starter hint — MuJoCo XML structure:
            <mujoco>
              <option timestep="0.002" gravity="0 0 -9.81"/>
              <asset>
                <texture .../>  <material .../>  <hfield .../>
              </asset>
              <worldbody>
                <light .../>
                <geom name="floor" type="hfield" .../>
                <body name="torso" ...>
                  <!-- torso geom, IMU sites, child leg bodies -->
                </body>
              </worldbody>
              <tendon/>   <!-- optional: couple knee to hip for passive compliance -->
              <actuator/>
              <sensor/>
              <contact>
                <!-- exclude self-collision pairs -->
              </contact>
            </mujoco>

        Returns:
            A valid MuJoCo XML string.
        """
        # TODO: Implement this method
        raise NotImplementedError("Part 1a: Implement build_xml()")

    def mutate(self, sigma: float = 0.05, rng: Optional[np.random.Generator] = None) -> "QuadrupedMorphology":
        """
        Return a new morphology with Gaussian-perturbed genome.
        Implements a (1+1)-ES mutation step.

        Args:
            sigma: Mutation step size (fraction of parameter value)
            rng:   Random number generator for reproducibility

        Returns:
            A new QuadrupedMorphology with mutated genome.

        ALife Connection: In evolutionary robotics, mutation operators
        determine the reachable phenotype space. Too large → destructive.
        Too small → slow exploration. Adaptive sigma (CMA-ES) is state-of-art.

        TODO: Implement Gaussian mutation clamped to valid parameter ranges.
        """
        raise NotImplementedError("Part 1c: Implement mutate()")

    def crossover(self, other: "QuadrupedMorphology") -> "QuadrupedMorphology":
        """
        Uniform crossover between two parent genomes.
        Each gene independently chosen from parent A or B with p=0.5.

        TODO: Implement uniform crossover.
        """
        raise NotImplementedError("Bonus: Implement crossover()")


# ---------------------------------------------------------------------------
# PART 2 — Central Pattern Generator (CPG) Controller
# ---------------------------------------------------------------------------

class CPGController:
    """
    A biologically-inspired Central Pattern Generator controller.

    Real animals (lamprey, salamander, cat) use spinal CPGs — networks of
    neurons that produce rhythmic motor patterns WITHOUT continuous sensory
    input. Ijspeert (2008) showed that simple coupled oscillators can
    reproduce biological gait diversity.

    This CPG has:
      - 8 oscillators (one per joint: 4 hips + 4 knees)
      - Kuramoto-style phase coupling between legs
      - Sensory feedback modulation (stumble reflex)
      - Energy tracking (metabolic cost estimation)

    Gait emerges from coupling topology:
      - Trot:  diagonal pairs in-phase, ipsilateral pairs anti-phase
      - Walk:  metachronal wave (RF→RH→LF→LH)
      - Bound: front pair in-phase, rear pair in-phase, 180° between pairs

    ALife Connection: CPGs exemplify how complex, adaptive behavior
    (locomotion) emerges from simple local rules — a core ALife principle.

    TODO (Part 2a): Implement `step` to integrate oscillator dynamics
    TODO (Part 2b): Implement `stumble_reflex` using foot touch sensors
    TODO (Part 2c): Implement `get_metabolic_cost` for homeostasis tracking
    """

    GAIT_COUPLINGS = {
        # Phase offsets between leg oscillators: (RF, LF, RH, LH)
        # 0 = in-phase, 0.5 = anti-phase (fractions of 2π)
        "trot":  np.array([0.0, 0.5, 0.5, 0.0]),   # diagonal pairs
        "walk":  np.array([0.0, 0.25, 0.5, 0.75]),  # sequential wave
        "bound": np.array([0.0, 0.0, 0.5, 0.5]),    # front+rear pairs
        "pace":  np.array([0.0, 0.5, 0.0, 0.5]),    # ipsilateral pairs
    }

    def __init__(
        self,
        n_oscillators: int = 8,
        base_frequency: float = 1.5,   # Hz
        amplitude: float = 0.6,         # radians
        gait: str = "trot",
        dt: float = 0.002,
    ):
        self.n = n_oscillators
        self.freq = base_frequency
        self.amp = amplitude
        self.dt = dt
        self.gait = gait

        # Oscillator state
        self.phases = np.zeros(n_oscillators)      # current phases (radians)
        self.velocities = np.zeros(n_oscillators)  # phase velocities

        # Energy / homeostasis tracking
        self.metabolic_cost = 0.0
        self.cumulative_work = 0.0

        # Coupling matrix: shape (n_oscillators, n_oscillators)
        self.coupling = self._build_coupling_matrix(gait)

    def _build_coupling_matrix(self, gait: str) -> np.ndarray:
        """
        Build inter-oscillator coupling matrix based on gait type.

        Leg order: [RF_hip, RF_knee, LF_hip, LF_knee, RH_hip, RH_knee, LH_hip, LH_knee]
        Hip-knee coupling within each leg: strong, in-phase (knee follows hip)
        Cross-leg coupling: from GAIT_COUPLINGS phase targets

        TODO: Build the full 8×8 coupling matrix.
        Returns: numpy array shape (8, 8) of coupling weights
        """
        raise NotImplementedError("Part 2a: Implement _build_coupling_matrix()")

    def step(self, sensor_data: Dict[str, np.ndarray]) -> np.ndarray:
        """
        Advance CPG by one timestep and return joint angle targets.

        Dynamics (modified Kuramoto model):
            dφ_i/dt = ω_i + Σ_j K_ij * sin(φ_j - φ_i - Δ_ij)

        where ω_i is natural frequency, K_ij coupling weight,
        Δ_ij desired phase difference.

        Args:
            sensor_data: dict with keys:
                'touch'   : (4,) float array, foot contact forces
                'gyro'    : (3,) angular velocity of torso
                'acc'     : (3,) linear acceleration
                'rangefwd': float, forward range reading
                'rangedn' : float, downward range reading

        Returns:
            joint_targets: (8,) array of target joint angles (radians)

        TODO: Implement Kuramoto dynamics + stumble reflex modulation
        """
        raise NotImplementedError("Part 2a: Implement step()")

    def stumble_reflex(self, touch: np.ndarray) -> np.ndarray:
        """
        Modulate oscillator amplitude based on unexpected foot contact.

        Biological basis: When an insect leg hits an unexpected obstacle,
        local reflexes lift the leg higher on next step WITHOUT central
        command. This is purely embodied, sensorimotor-loop behavior.

        Args:
            touch: (4,) foot touch sensor readings (Newtons)

        Returns:
            amplitude_modulation: (4,) per-leg amplitude scale factors

        TODO: Implement reflex — legs with HIGH unexpected contact during
        swing phase should briefly increase lift amplitude.
        """
        raise NotImplementedError("Part 2b: Implement stumble_reflex()")

    def get_metabolic_cost(self, torques: np.ndarray, velocities: np.ndarray) -> float:
        """
        Estimate instantaneous metabolic cost using muscle model.

        Simplified Hill muscle model cost:
            P = Σ |τ_i * ω_i| * (1 + heat_rate)

        Args:
            torques: (8,) joint torques (from mujoco data.actuator_force)
            velocities: (8,) joint angular velocities (data.qvel[relevant])

        Returns:
            Instantaneous metabolic power (Watts equivalent)

        ALife Connection: Energy budget is a KEY selective pressure in
        biological evolution. Organisms that locomote more efficiently
        out-compete wasteful ones. This drives gait optimization.

        TODO: Implement metabolic cost calculation.
        """
        raise NotImplementedError("Part 2c: Implement get_metabolic_cost()")

    def switch_gait(self, new_gait: str):
        """Switch gait smoothly by rebuilding coupling matrix."""
        if new_gait not in self.GAIT_COUPLINGS:
            raise ValueError(f"Unknown gait: {new_gait}. Choose from {list(self.GAIT_COUPLINGS)}")
        self.gait = new_gait
        self.coupling = self._build_coupling_matrix(new_gait)


# ---------------------------------------------------------------------------
# PART 3 — Terrain Generator
# ---------------------------------------------------------------------------

class TerrainGenerator:
    """
    Procedurally generate disaster-zone terrain using MuJoCo heightfields.

    Terrain types:
      - 'flat'    : baseline (control condition)
      - 'rubble'  : Perlin-noise bumps (high-frequency)
      - 'slope'   : gradual incline then decline
      - 'gaps'    : periodic flat gaps (agent must step over or around)

    MuJoCo Feature: hfield asset + geom allow realistic terrain with
    proper contact dynamics — far more realistic than flat plane + obstacles.

    ALife Connection: Terrain is the SELECTIVE ENVIRONMENT. ALife teaches
    that behavior cannot be understood without its environment — Lewontin's
    "organism-environment co-construction."

    TODO (Part 3): Implement at least 2 non-trivial terrain generators.
    """

    def __init__(self, size: Tuple[int, int] = (128, 128), scale: float = 5.0):
        self.nx, self.ny = size
        self.scale = scale  # physical size in meters

    def generate(self, terrain_type: str = "rubble", seed: int = 42) -> np.ndarray:
        """
        Generate heightfield as a (nx, ny) float32 array in [0, 1].

        Args:
            terrain_type: one of 'flat', 'rubble', 'slope', 'gaps'
            seed: random seed for reproducibility

        Returns:
            heights: (nx, ny) float32 array

        TODO: Implement at least 'rubble' using fractal Perlin noise
              and 'gaps' using periodic step function.
        Hint: Use scipy.ndimage.gaussian_filter for smooth noise.
        """
        rng = np.random.default_rng(seed)

        if terrain_type == "flat":
            return np.zeros((self.nx, self.ny), dtype=np.float32)

        elif terrain_type == "rubble":
            # TODO: Generate fractal noise terrain
            # Hint: Sum multiple octaves of random noise at different scales
            raise NotImplementedError("Part 3: Implement 'rubble' terrain")

        elif terrain_type == "slope":
            # TODO: Gentle slope upward then downward
            raise NotImplementedError("Part 3: Implement 'slope' terrain")

        elif terrain_type == "gaps":
            # TODO: Periodic chasms the robot must cross
            raise NotImplementedError("Part 3: Implement 'gaps' terrain")

        else:
            raise ValueError(f"Unknown terrain: {terrain_type}")

    def embed_in_xml(self, xml_string: str, heights: np.ndarray) -> str:
        """
        Embed heightfield data into an existing MuJoCo XML string.

        MuJoCo requires hfield data as space-separated floats in the
        <hfield> asset tag, or loaded from .png file.

        TODO: Parse xml_string with ElementTree, find <hfield> element,
        insert the height data, return modified XML string.
        """
        raise NotImplementedError("Part 3: Implement embed_in_xml()")


# ---------------------------------------------------------------------------
# PART 4 — Evolutionary Optimization
# ---------------------------------------------------------------------------

class EvolutionaryOptimizer:
    """
    (1+λ)-Evolution Strategy for co-evolving morphology and CPG parameters.

    This implements the core ALife concept of EVOLUTIONARY ROBOTICS:
    letting natural selection — rather than human engineering — discover
    effective body-brain configurations.

    Fitness function: distance traveled / metabolic cost
                      (efficiency, not just speed — biologically motivated)

    TODO (Part 4a): Implement `evaluate_individual` — run MuJoCo simulation
                    for T seconds and return fitness score
    TODO (Part 4b): Implement `run_generation` — evaluate λ offspring,
                    select best, log population statistics
    TODO (Part 4c): Implement fitness landscape visualization
    """

    def __init__(
        self,
        population_size: int = 20,
        n_generations: int = 50,
        episode_duration: float = 10.0,  # seconds per evaluation
        terrain_type: str = "rubble",
        sigma_morph: float = 0.05,
        sigma_cpg: float = 0.1,
    ):
        self.pop_size = population_size
        self.n_gen = n_generations
        self.T = episode_duration
        self.terrain = terrain_type
        self.sigma_m = sigma_morph
        self.sigma_c = sigma_cpg

        self.history: List[Dict] = []   # fitness log per generation

    def evaluate_individual(
        self,
        morphology: QuadrupedMorphology,
        cpg: CPGController,
        terrain_heights: np.ndarray,
        render: bool = False,
    ) -> Dict[str, float]:
        """
        Simulate agent for self.T seconds and return fitness metrics.

        Steps:
          1. Build XML (morphology.build_xml())
          2. Embed terrain heightfield
          3. Load with mujoco.MjModel.from_xml_string()
          4. Create MjData, run simulation loop
          5. At each step: read sensors → CPG → set ctrl → mj_step
          6. Track: displacement, metabolic cost, falls (torso contact)

        Args:
            morphology: QuadrupedMorphology instance
            cpg: CPGController instance
            terrain_heights: (nx, ny) heightfield array
            render: If True, open viewer (use only for best individual)

        Returns:
            metrics dict with keys:
              'fitness'   : float (primary selection criterion)
              'distance'  : float (meters traveled)
              'efficiency': float (distance / metabolic_cost)
              'fell'      : bool (torso contacted ground)
              'gait_stability': float (variance in step timing)

        TODO: Implement full simulation loop using MuJoCo Python bindings.

        Key MuJoCo API calls to use:
            model = mujoco.MjModel.from_xml_string(xml_str)
            data  = mujoco.MjData(model)
            mujoco.mj_step(model, data)
            data.sensordata   → all sensor readings (flat array)
            data.ctrl[:]      → set actuator controls
            data.qpos, data.qvel → state
            data.contact      → contact information
            model.sensor_adr, model.sensor_dim → sensor layout
        """
        raise NotImplementedError("Part 4a: Implement evaluate_individual()")

    def run_generation(
        self,
        parent_morph: QuadrupedMorphology,
        parent_cpg_params: Dict,
    ) -> Tuple[QuadrupedMorphology, Dict, float]:
        """
        Run one (1+λ) generation:
          1. Create λ offspring via mutation
          2. Evaluate all offspring
          3. Return best (individual, cpg_params, fitness)
          4. Log population statistics

        TODO: Implement generation loop.
        """
        raise NotImplementedError("Part 4b: Implement run_generation()")

    def evolve(self, seed_morphology: Optional[QuadrupedMorphology] = None) -> Dict:
        """
        Full evolutionary run across self.n_gen generations.

        Returns:
            results dict with 'best_morphology', 'best_fitness',
            'history', 'fitness_curve' (numpy array)

        TODO: Implement full evolutionary loop.
              Print progress each generation.
              Save checkpoints every 10 generations.
        """
        raise NotImplementedError("Part 4b: Implement evolve()")


# ---------------------------------------------------------------------------
# PART 5 — Multi-Agent Collective Behavior
# ---------------------------------------------------------------------------

class SwarmSimulation:
    """
    Multiple quadrupeds co-existing in the same terrain.

    ALife Emergent Behavior: When multiple agents share an environment,
    collective phenomena emerge that are IMPOSSIBLE to predict from
    studying individuals alone (Reynolds' Boids, ant foraging, etc.).

    Here: agents must navigate around each other while traversing terrain.
    No explicit coordination — only local sensing (rangefinders).

    Emergent phenomena to observe:
      - Traffic-like flow patterns
      - Spontaneous lane formation
      - Deadlock (and resolution strategies)

    MuJoCo Feature: Multiple bodies in one simulation, contact dynamics
    between agents, shared terrain.

    TODO (Part 5): Implement multi-agent simulation.
    Bonus: Implement a simple stigmergy mechanism (pheromone grid).
    """

    def __init__(self, n_agents: int = 4, terrain_type: str = "rubble"):
        self.n_agents = n_agents
        self.terrain_type = terrain_type
        self.agents: List[Dict] = []

    def build_multi_agent_xml(
        self,
        morphologies: List[QuadrupedMorphology],
        start_positions: List[Tuple[float, float]],
    ) -> str:
        """
        Combine multiple agent XML bodies into one MuJoCo scene.

        Each agent body is prefixed with 'agent{i}_' for unique naming.
        All agents share the same heightfield terrain.

        TODO: Implement by building individual XMLs and merging worldbody sections.
        """
        raise NotImplementedError("Part 5: Implement build_multi_agent_xml()")

    def run(self, duration: float = 30.0, render: bool = True) -> Dict:
        """
        Run multi-agent simulation and track collective metrics:
          - Mean velocity of all agents
          - Collision count
          - Spatial distribution (do they spread out or cluster?)
          - Any agent reached the goal (far end of terrain)?

        TODO: Implement simulation loop with per-agent CPG controllers.
        """
        raise NotImplementedError("Part 5: Implement run()")


# ---------------------------------------------------------------------------
# PART 6 — Analysis & Visualization
# ---------------------------------------------------------------------------

class ExperimentAnalyzer:
    """
    Analyze and visualize evolutionary and behavioral results.

    Required plots (use matplotlib):
      1. Fitness curve: mean ± std per generation
      2. Gait diagram: foot contact pattern over time (ethogram)
      3. Morphology comparison: bar chart of evolved vs default genome
      4. Energy landscape: 2D heatmap of fitness over 2 key genome params
      5. Phase portrait: CPG oscillator phases over time

    TODO (Part 6): Implement all 5 visualizations.
    """

    def __init__(self, results_dir: str = "results"):
        self.results_dir = Path(results_dir)
        self.results_dir.mkdir(exist_ok=True)

    def plot_fitness_curve(self, history: List[Dict]) -> None:
        """Plot evolutionary fitness over generations with confidence band."""
        raise NotImplementedError("Part 6: Implement plot_fitness_curve()")

    def plot_gait_diagram(self, foot_contacts: np.ndarray, dt: float) -> None:
        """
        Plot gait ethogram: time × 4 feet contact pattern.
        Expected output: horizontal bars (black=stance, white=swing) for each foot.
        """
        raise NotImplementedError("Part 6: Implement plot_gait_diagram()")

    def plot_morphology_comparison(
        self,
        default: QuadrupedMorphology,
        evolved: QuadrupedMorphology,
    ) -> None:
        """Bar chart comparing genome parameters: default vs evolved."""
        raise NotImplementedError("Part 6: Implement plot_morphology_comparison()")

    def plot_energy_landscape(
        self,
        optimizer: EvolutionaryOptimizer,
        param1: str,
        param2: str,
        n_points: int = 10,
    ) -> None:
        """
        2D fitness landscape over two morphological parameters.
        Reveals fitness peaks and valleys — visualizes adaptive landscape.

        ALife Connection: Wright's (1932) adaptive landscape metaphor is
        central to evolutionary theory. Visualizing it directly is powerful.
        """
        raise NotImplementedError("Part 6: Implement plot_energy_landscape()")

    def plot_phase_portrait(self, phase_history: np.ndarray) -> None:
        """Polar plot of CPG oscillator phases over time."""
        raise NotImplementedError("Part 6: Implement plot_phase_portrait()")


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def main():
    """
    Run the full pipeline:
      1. Generate terrain
      2. Build default morphology & CPG
      3. Evolve for N generations
      4. Render best individual
      5. Run multi-agent experiment
      6. Generate all analysis plots

    Run modes (set via command-line arg or env variable):
      'test'   : 1 generation, 2 offspring, 3-second episodes (quick check)
      'demo'   : Load pre-evolved genome, render, plot (no evolution)
      'full'   : Full evolutionary run (may take ~30 min)
    """
    import sys
    mode = sys.argv[1] if len(sys.argv) > 1 else "test"

    print(f"\n{'='*60}")
    print(f"  Embodied ALife Exercise — Mode: {mode.upper()}")
    print(f"{'='*60}\n")

    # Step 1: Terrain
    terrain_gen = TerrainGenerator(size=(64, 64), scale=5.0)
    terrain_heights = terrain_gen.generate("rubble", seed=42)
    print(f"[1/6] Terrain generated: shape={terrain_heights.shape}, "
          f"max_height={terrain_heights.max():.3f}")

    # Step 2: Default morphology
    morph = QuadrupedMorphology()
    cpg = CPGController(gait="trot")
    print(f"[2/6] Default morphology & CPG initialized")

    # Step 3: Evolution
    optimizer = EvolutionaryOptimizer(
        population_size=4 if mode == "test" else 20,
        n_generations=1  if mode == "test" else 50,
        episode_duration=3.0 if mode == "test" else 10.0,
        terrain_type="rubble",
    )
    print(f"[3/6] Starting evolution ({optimizer.n_gen} gens × {optimizer.pop_size} pop)...")
    results = optimizer.evolve(seed_morphology=morph)
    print(f"      Best fitness: {results.get('best_fitness', 'N/A'):.4f}")

    # Step 4: Render best (if not headless)
    print(f"[4/6] Rendering best individual (close viewer to continue)...")
    # optimizer.evaluate_individual(..., render=True)  # uncomment when implemented

    # Step 5: Multi-agent
    print(f"[5/6] Running multi-agent collective simulation...")
    swarm = SwarmSimulation(n_agents=2 if mode == "test" else 4, terrain_type="rubble")
    # swarm.run(duration=10.0, render=True)  # uncomment when implemented

    # Step 6: Analysis
    print(f"[6/6] Generating analysis plots in ./results/ ...")
    analyzer = ExperimentAnalyzer()
    if results.get("history"):
        analyzer.plot_fitness_curve(results["history"])

    print(f"\n✓ Exercise complete. Check ./results/ for plots.\n")


if __name__ == "__main__":
    main()
