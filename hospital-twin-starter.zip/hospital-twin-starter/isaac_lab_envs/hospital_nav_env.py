"""
isaac_lab_envs/hospital_nav_env.py
====================================
Task 4: Isaac Lab reinforcement learning environment for hospital crowd navigation.

The robot must navigate from a start position to a delivery goal while avoiding
randomly spawned pedestrian agents. This task requires a learned policy because
the pedestrians' paths are stochastic and cannot be modelled analytically.

Key embodied AI insight
-----------------------
The robot's sensory body (lidar scan) directly shapes what it can "know" about
the world. The RL policy must learn from raw sensor data — it cannot access
ground-truth pedestrian positions, only what the lidar reports. This is the
*grounding* problem: intelligence is constrained and enabled by the physical body.

Isaac Lab reference: https://isaac-sim.github.io/IsaacLab/
Task tutorial:       https://isaac-sim.github.io/IsaacLab/source/tutorials/05_controllers/index.html
"""

from __future__ import annotations

import math
import torch
from dataclasses import MISSING

# Isaac Lab imports — require Isaac Lab conda env
try:
    import omni.isaac.lab.sim as sim_utils
    from omni.isaac.lab.assets import Articulation, ArticulationCfg
    from omni.isaac.lab.envs import DirectRLEnv, DirectRLEnvCfg
    from omni.isaac.lab.scene import InteractiveSceneCfg
    from omni.isaac.lab.sim import SimulationCfg
    from omni.isaac.lab.terrains import TerrainImporterCfg
    from omni.isaac.lab.utils import configclass
    from omni.isaac.lab.sensors import RayCasterCfg, patterns
except ImportError:
    raise ImportError(
        "Isaac Lab not found. Activate the isaaclab conda environment:\n"
        "  conda activate isaaclab\n"
        "See: https://isaac-sim.github.io/IsaacLab/source/setup/installation/"
    )


# ── Environment configuration ────────────────────────────────────────────────

@configclass
class HospitalNavEnvCfg(DirectRLEnvCfg):
    """Configuration dataclass for the HospitalNavEnv.

    All fields here drive Isaac Lab's internal setup — change them here,
    not inside the Env class methods.
    """

    # Simulation timing
    sim: SimulationCfg = SimulationCfg(dt=0.02, render_interval=4)   # 50 Hz physics

    # Episode setup
    episode_length_s: float = 30.0       # max episode duration (seconds)
    num_envs: int = 16                   # parallel simulation copies
    env_spacing: float = 8.0            # meters between env origins

    # TODO Task 4: Define observation and action dimensions.
    # Observation space components:
    #   - lidar_ranges: 360 ray distances (m), normalised to [0, 1]
    #   - goal_polar:   (dist, angle) to delivery goal, normalised
    #   - ped_vels:     up to 5 pedestrians × (vx, vy) = 10 floats
    # Total: 360 + 2 + 10 = 372
    num_observations: int = 372          # FIXME: adjust if you change components

    # Action space: [linear_vel, angular_vel] in robot frame
    # Normalised to [-1, 1]; scaled inside _apply_action()
    num_actions: int = 2

    # Physics and safety
    max_lin_vel: float = 0.5    # m/s  — TurtleBot4 safe limit
    max_ang_vel: float = 1.0    # rad/s
    collision_radius: float = 0.35  # m — AMR footprint radius
    goal_radius: float = 0.3    # m — consider "goal reached" within this

    # Reward weights — tune these during Task 4
    reward_goal_reach: float  = 100.0
    reward_collision:  float  = -50.0
    reward_progress:   float  = 1.0    # per step closer to goal
    reward_energy:     float  = -0.01  # per |action| step

    # Environment asset paths (within the Isaac Sim nucleus or local)
    hospital_usd_path: str = "omniverse://localhost/Projects/hospital_ward.usd"
    turtlebot_usd_path: str = (
        "omniverse://localhost/Isaac/Robots/Turtlebot/turtlebot4.usd"
    )

    # Pedestrian configuration
    num_pedestrians: int = 5
    ped_speed_range: tuple[float, float] = (0.3, 0.8)  # m/s


# ── Isaac Lab environment ─────────────────────────────────────────────────────

class HospitalNavEnv(DirectRLEnv):
    """Isaac Lab DirectRL environment: hospital crowd navigation.

    Inherits from DirectRLEnv which handles parallel simulation, reset logic,
    and the RL training loop. You implement the four abstract methods below.

    Parallel simulation
    -------------------
    Isaac Lab runs `num_envs` copies of the scene simultaneously on GPU.
    All tensors have shape [num_envs, ...]. Index with `env_ids` to reset
    only terminated environments.
    """

    cfg: HospitalNavEnvCfg

    def __init__(self, cfg: HospitalNavEnvCfg, render_mode: str | None = None):
        super().__init__(cfg, render_mode=render_mode)
        self._init_buffers()

    # ── Buffer initialisation ─────────────────────────────────────────────────

    def _init_buffers(self) -> None:
        """Initialise tensors that persist across steps."""
        self.goal_positions = torch.zeros(
            (self.num_envs, 2), device=self.device
        )  # (x, y) for each parallel env
        self.prev_distances = torch.full(
            (self.num_envs,), fill_value=float("inf"), device=self.device
        )
        self.ped_positions = torch.zeros(
            (self.num_envs, self.cfg.num_pedestrians, 2), device=self.device
        )
        self.ped_velocities = torch.zeros_like(self.ped_positions)

    # ── Scene setup ───────────────────────────────────────────────────────────

    def _setup_scene(self) -> None:
        """Load the hospital USD scene and spawn the TurtleBot4 + pedestrians.

        Called once at environment initialisation.

        TODO Task 4:
        1. Import hospital_ward.usd using sim_utils.UsdFileCfg
        2. Spawn self.robot (Articulation) from turtlebot4.usd
        3. Add a RayCasterCfg lidar sensor (360 rays, 5 m range)
        4. Spawn self.cfg.num_pedestrians as simple capsule prims (pedestrians)
        5. Call self.scene.clone_environments(copy_from_source=False)
        6. Add lights: sim_utils.DistantLightCfg

        Hint: See IsaacLab tutorials for example scene setup:
        https://isaac-sim.github.io/IsaacLab/source/tutorials/01_assets/index.html
        """
        raise NotImplementedError("TODO Task 4: implement _setup_scene()")

    # ── Observation ───────────────────────────────────────────────────────────

    def _get_observations(self) -> dict[str, torch.Tensor]:
        """Construct the observation dict for all parallel environments.

        Returns
        -------
        dict with key 'policy' → Tensor of shape [num_envs, num_observations]

        Observation vector layout (all normalised to roughly [-1, 1]):
          [0:360]    lidar ranges / max_range  (360 rays)
          [360:362]  goal polar: [dist/10, angle/pi]
          [362:372]  pedestrian velocities: [vx/max_v, vy/max_v] × 5 peds

        TODO Task 4:
        1. Read lidar data from the RayCaster sensor
        2. Compute robot→goal vector in robot frame, convert to polar
        3. Read pedestrian positions, compute velocities via finite diff
        4. Concatenate into a single [num_envs, 372] tensor
        """
        raise NotImplementedError("TODO Task 4: implement _get_observations()")

    # ── Reward ────────────────────────────────────────────────────────────────

    def _get_rewards(self) -> torch.Tensor:
        """Compute the shaped reward for all parallel environments.

        Returns
        -------
        Tensor of shape [num_envs] — one reward per parallel env.

        Reward components (all configurable via HospitalNavEnvCfg):
          + reward_goal_reach   when dist_to_goal < goal_radius
          + reward_collision     when a collision is detected
          + reward_progress × Δdist  (negative if moving away)
          + reward_energy × ||action||  (regulariser)

        TODO Task 4:
        1. Compute distance to goal for each env
        2. Compute progress = prev_distance - current_distance
        3. Detect collisions using the lidar (min_range < collision_radius)
        4. Sum the reward components
        5. Update self.prev_distances

        Design note: The collision penalty and goal reward will dominate early
        training. The progress reward helps the agent keep moving. The energy
        penalty discourages erratic spinning — critical in a hospital corridor.
        """
        raise NotImplementedError("TODO Task 4: implement _get_rewards()")

    # ── Termination ───────────────────────────────────────────────────────────

    def _get_dones(self) -> tuple[torch.Tensor, torch.Tensor]:
        """Determine which environments are done this step.

        Returns
        -------
        (terminated, truncated) — each a bool Tensor of shape [num_envs]

        terminated : goal reached OR collision (episode ends with a definitive outcome)
        truncated  : episode_length_s exceeded (time limit, no penalty)

        TODO Task 4: implement using distance-to-goal and lidar min-range checks.
        """
        raise NotImplementedError("TODO Task 4: implement _get_dones()")

    # ── Reset ─────────────────────────────────────────────────────────────────

    def _reset_idx(self, env_ids: torch.Tensor) -> None:
        """Reset specific environments (only the ones that terminated/truncated).

        Parameters
        ----------
        env_ids : 1D Tensor of environment indices to reset

        TODO Task 4:
        1. Randomise robot start pose (x, y, yaw) within safe corridor area
        2. Randomise goal position (another room in the ward)
        3. Randomise pedestrian start positions and assign random walk targets
        4. Update self.goal_positions[env_ids] and self.prev_distances[env_ids]
        5. Write new root state to physics simulation

        Hint: Use torch.rand_like() for vectorised random sampling.
        Ensure start ≠ goal (check distance > 1.5 m).
        """
        raise NotImplementedError("TODO Task 4: implement _reset_idx()")

    # ── Action application ─────────────────────────────────────────────────────

    def _apply_action(self) -> None:
        """Scale normalised policy output and apply velocity commands to robot.

        The policy outputs actions in [-1, 1]. Scale to physical limits:
          linear_vel  = action[..., 0] × max_lin_vel
          angular_vel = action[..., 1] × max_ang_vel

        Then apply via the robot's velocity controller.

        TODO Task 4: implement using self.robot.set_joint_velocity_target()
        or the differential drive controller if available.
        """
        raise NotImplementedError("TODO Task 4: implement _apply_action()")

    # ── Pedestrian update ─────────────────────────────────────────────────────

    def _update_pedestrians(self) -> None:
        """Move pedestrian agents using a random walk with obstacle avoidance.

        Called every simulation step. Pedestrians use a simple heading + noise
        model — they are not RL agents, just dynamic obstacles.

        TODO (optional extension):
        Replace with social force model for more realistic crowd behaviour:
        https://arxiv.org/abs/1007.4371
        """
        pass  # Stub — implement for full Task 4 credit
