"""
isaac_lab_envs/train_ppo.py
=============================
Task 4: Train a PPO policy on HospitalNavEnv using Isaac Lab's built-in runner.

Usage
-----
conda activate isaaclab
python isaac_lab_envs/train_ppo.py --num_envs 16 --max_iterations 5000

For headless training (recommended on remote servers):
python isaac_lab_envs/train_ppo.py --headless --num_envs 64

References
----------
Isaac Lab RL: https://isaac-sim.github.io/IsaacLab/source/tutorials/03_envs/index.html
RSL-RL (PPO): https://github.com/leggedrobotics/rsl_rl
"""

import argparse

# Isaac Lab app launcher must be created before any other omni imports
from omni.isaac.lab.app import AppLauncher

parser = argparse.ArgumentParser(description="Train hospital navigation policy")
parser.add_argument("--num_envs",       type=int,   default=16,    help="Parallel environments")
parser.add_argument("--max_iterations", type=int,   default=5000,  help="Training iterations")
parser.add_argument("--checkpoint",     type=str,   default=None,  help="Resume from checkpoint path")
parser.add_argument("--headless",       action="store_true",       help="Run without GUI")
parser.add_argument("--video",          action="store_true",       help="Record video")
AppLauncher.add_app_launcher_args(parser)
args, _ = parser.parse_known_args()

# Launch Isaac Sim app
app_launcher = AppLauncher(args)
simulation_app = app_launcher.app

# --- All Isaac/omni imports AFTER AppLauncher ---
import torch
from omni.isaac.lab_tasks.utils import parse_env_cfg
from omni.isaac.lab.utils.dict import print_dict

# RSL-RL is the PPO implementation bundled with Isaac Lab
try:
    from rsl_rl.runners import OnPolicyRunner
except ImportError:
    raise ImportError(
        "rsl_rl not found. Install via: pip install rsl-rl\n"
        "Or use the isaaclab conda env: conda activate isaaclab"
    )

from hospital_nav_env import HospitalNavEnv, HospitalNavEnvCfg


# ── PPO hyperparameters ───────────────────────────────────────────────────────
# These are starting points. Students should tune them for Task 4.
TRAIN_CFG = {
    "seed": 42,
    "runner": {
        "num_steps_per_env": 24,        # steps per rollout per env
        "max_iterations": args.max_iterations,
        "save_interval": 500,
        "experiment_name": "hospital_nav",
        "run_name": "",
        "resume": args.checkpoint is not None,
        "load_run": args.checkpoint or "",
        "checkpoint": -1,               # -1 = latest
        "logger": "tensorboard",
        "wandb_project": "embodied-ai-course",
    },
    "policy": {
        "class_name": "ActorCritic",
        "init_noise_std": 1.0,
        # MLP architecture: input → hidden → hidden → output
        "actor_hidden_dims":  [512, 256, 128],
        "critic_hidden_dims": [512, 256, 128],
        "activation": "elu",
    },
    "algorithm": {
        "class_name": "PPO",
        "value_loss_coef": 1.0,
        "use_clipping": True,
        "clip_param": 0.2,
        "entropy_coef": 0.005,
        "num_learning_epochs": 5,
        "num_mini_batches": 4,
        "learning_rate": 1.0e-3,
        "schedule": "adaptive",         # adapts LR based on KL divergence
        "gamma": 0.99,
        "lam": 0.95,
        "desired_kl": 0.01,
        "max_grad_norm": 1.0,
    },
}


def main():
    # Build environment config
    env_cfg = HospitalNavEnvCfg()
    env_cfg.num_envs = args.num_envs

    # Create the Isaac Lab environment
    env = HospitalNavEnv(cfg=env_cfg, render_mode="rgb_array" if args.video else None)

    print(f"\n[Train] Environment: {env_cfg.num_envs} parallel envs")
    print(f"[Train] Obs dim: {env.num_observations}  |  Act dim: {env.num_actions}")
    print(f"[Train] Episode length: {env_cfg.episode_length_s} s")
    print(f"[Train] Max iterations: {args.max_iterations}\n")

    # Create RSL-RL OnPolicyRunner (wraps PPO, handles logging & checkpointing)
    runner = OnPolicyRunner(env, TRAIN_CFG, log_dir="checkpoints/ppo_hospital_nav")

    if args.checkpoint:
        runner.load(args.checkpoint)
        print(f"[Train] Resumed from checkpoint: {args.checkpoint}")

    # ── Training loop ─────────────────────────────────────────────────────────
    # RSL-RL handles the full loop: collect rollouts → compute advantages → PPO update
    runner.learn(num_learning_iterations=args.max_iterations, init_at_random_ep_len=True)

    # ── Save final policy ─────────────────────────────────────────────────────
    save_path = "checkpoints/ppo_hospital_nav/final_policy.pt"
    runner.save(save_path)
    print(f"\n[Train] Saved final policy to: {save_path}")

    env.close()
    simulation_app.close()


if __name__ == "__main__":
    main()
