"""
hospital_twin/system_monitor.py
================================
Publishes RViz2 and Foxglove markers for the hospital dashboard:
  - Patient vitals as text markers on a ward map
  - Priority-coloured sphere markers at each room position
  - Robot delivery trail as a path marker
  - Live NEWS2 score bar for each patient

No TODOs — this node is provided complete for students to use as a
visualization aid while implementing Tasks 2–5.
"""

from __future__ import annotations
import json
from pathlib import Path

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy
from std_msgs.msg import Float32, ColorRGBA
from visualization_msgs.msg import Marker, MarkerArray
from geometry_msgs.msg import Point

from hospital_twin_msgs.msg import PatientVitals
from .news2_scorer import priority_to_ros_color

PATIENT_IDS = ["p001", "p002", "p003", "p004", "p005"]


class SystemMonitor(Node):
    """Publishes RViz2/Foxglove visualization markers for the hospital twin."""

    def __init__(self) -> None:
        super().__init__("system_monitor")

        self.declare_parameter("room_map_path", "data/patient_room_map.json")
        map_path = self.get_parameter("room_map_path").value
        self.room_map: dict = self._load_room_map(map_path)

        self.vitals:   dict[str, PatientVitals | None] = {p: None for p in PATIENT_IDS}
        self.priorities: dict[str, float]              = {p: 0.0  for p in PATIENT_IDS}

        qos = QoSProfile(reliability=ReliabilityPolicy.BEST_EFFORT, depth=5)

        # Subscribe to vitals and priorities for every patient
        for pid in PATIENT_IDS:
            self.create_subscription(
                PatientVitals, f"/patient/{pid}/vitals",
                lambda msg, p=pid: self._vitals_cb(msg, p), qos)
            self.create_subscription(
                Float32, f"/patient/{pid}/priority",
                lambda msg, p=pid: self._priority_cb(msg, p), qos)

        # Single marker array publisher consumed by RViz2 and Foxglove
        self.marker_pub = self.create_publisher(MarkerArray, "/hospital/markers", 10)

        self.create_timer(0.5, self._publish_markers)
        self.get_logger().info("SystemMonitor ready — publishing /hospital/markers at 2 Hz")

    # ── Callbacks ─────────────────────────────────────────────────────────────

    def _vitals_cb(self, msg: PatientVitals, pid: str) -> None:
        self.vitals[pid] = msg

    def _priority_cb(self, msg: Float32, pid: str) -> None:
        self.priorities[pid] = msg.data

    # ── Marker publishing ─────────────────────────────────────────────────────

    def _publish_markers(self) -> None:
        array = MarkerArray()
        now = self.get_clock().now().to_msg()

        for i, pid in enumerate(PATIENT_IDS):
            room = self.room_map.get(pid)
            if room is None:
                continue

            priority = self.priorities[pid]
            r, g, b, a = priority_to_ros_color(priority)
            color = ColorRGBA(r=r, g=g, b=b, a=a)

            # Sphere at room position coloured by priority
            sphere = Marker()
            sphere.header.frame_id = "map"
            sphere.header.stamp    = now
            sphere.ns              = "patient_priority"
            sphere.id              = i
            sphere.type            = Marker.SPHERE
            sphere.action          = Marker.ADD
            sphere.pose.position   = Point(x=room["x"], y=room["y"], z=0.8)
            sphere.scale.x = sphere.scale.y = sphere.scale.z = 0.4
            sphere.color           = color
            array.markers.append(sphere)

            # Text label with vitals
            vitals = self.vitals[pid]
            if vitals:
                label_text = (
                    f"{pid}\n"
                    f"HR:{vitals.heart_rate:.0f}  SpO2:{vitals.spo2:.0f}%\n"
                    f"RR:{vitals.resp_rate:.0f}  SBP:{vitals.systolic_bp:.0f}\n"
                    f"NEWS2:{priority:.1f}"
                )
            else:
                label_text = f"{pid}\n(waiting for data)"

            text = Marker()
            text.header.frame_id = "map"
            text.header.stamp    = now
            text.ns              = "patient_labels"
            text.id              = i + 100
            text.type            = Marker.TEXT_VIEW_FACING
            text.action          = Marker.ADD
            text.pose.position   = Point(x=room["x"], y=room["y"], z=1.4)
            text.scale.z         = 0.18
            text.color           = ColorRGBA(r=1.0, g=1.0, b=1.0, a=1.0)
            text.text            = label_text
            array.markers.append(text)

        self.marker_pub.publish(array)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _load_room_map(self, path: str) -> dict:
        p = Path(path)
        if p.exists():
            with open(p) as f:
                return json.load(f)
        self.get_logger().warning(f"Room map not found: {path}")
        return {}


def main(args=None) -> None:
    rclpy.init(args=args)
    node = SystemMonitor()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
