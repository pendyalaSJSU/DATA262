#!/usr/bin/env python3
"""
scripts/generate_sample_vitals.py
===================================
Generates a synthetic MIMIC-IV-like vitals CSV for students who have not yet
completed PhysioNet registration. Values are statistically realistic but NOT
derived from real patient data.

Run: python scripts/generate_sample_vitals.py
Output: data/mimic_vitals_sample.csv
"""

import numpy as np
import pandas as pd
from pathlib import Path

rng = np.random.default_rng(42)

PATIENT_IDS = ["p001", "p002", "p003", "p004", "p005"]
N_READINGS  = 200   # readings per patient

# Patient profiles: (baseline HR, baseline SpO2, baseline RR, deterioration_onset)
PROFILES = {
    "p001": dict(hr=72, spo2=98, rr=14, sbp=130, temp=37.0, deteriorates=False),
    "p002": dict(hr=68, spo2=97, rr=13, sbp=125, temp=36.8, deteriorates=False),
    "p003": dict(hr=80, spo2=95, rr=16, sbp=110, temp=37.2, deteriorates=True,  onset=120),
    "p004": dict(hr=75, spo2=96, rr=15, sbp=120, temp=37.1, deteriorates=False),
    "p005": dict(hr=85, spo2=94, rr=18, sbp=105, temp=37.5, deteriorates=True,  onset=60),
}

rows = []
for pid, prof in PROFILES.items():
    for i in range(N_READINGS):
        deteriorating = prof.get("deteriorates", False) and i > prof.get("onset", 9999)
        drift = (i - prof.get("onset", N_READINGS)) / 30.0 if deteriorating else 0.0

        hr   = rng.normal(prof["hr"]   + drift * 20,   4)
        spo2 = rng.normal(prof["spo2"] - drift * 3,    1)
        rr   = rng.normal(prof["rr"]   + drift * 5,    1.5)
        sbp  = rng.normal(prof["sbp"]  - drift * 15,   5)
        temp = rng.normal(prof["temp"] + drift * 0.3,  0.2)

        rows.append({
            "subject_id": pid,
            "charttime":  pd.Timestamp("2024-01-01") + pd.Timedelta(minutes=i * 5),
            "heart_rate": round(float(np.clip(hr,   20, 200)), 1),
            "spo2":       round(float(np.clip(spo2, 70, 100)), 1),
            "resp_rate":  round(float(np.clip(rr,   4,  40)),  1),
            "sbp":        round(float(np.clip(sbp,  60, 250)), 1),
            "dbp":        round(float(np.clip(sbp * 0.6 + rng.normal(0, 3), 40, 160)), 1),
            "temperature": round(float(np.clip(temp, 34, 42)), 1),
        })

df = pd.DataFrame(rows)
out = Path("data/mimic_vitals_sample.csv")
out.parent.mkdir(exist_ok=True)
df.to_csv(out, index=False)
print(f"Generated {len(df)} rows → {out}")
print(df.groupby("subject_id")[["heart_rate", "spo2", "resp_rate"]].mean().round(1))
