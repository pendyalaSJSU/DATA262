"""
hospital_twin/news2_scorer.py
==============================
Task 2: NEWS2 (National Early Warning Score 2) implementation.

NEWS2 is the UK standard for detecting patient deterioration in hospital.
It scores six physiological parameters, producing a composite risk level
used by clinical staff to escalate care.

Reference
---------
Royal College of Physicians:
https://www.rcplondon.ac.uk/projects/outputs/national-early-warning-score-news-2

NEWS2 scoring table
-------------------
Parameter        3      2      1      0      1      2      3
Resp rate       ≤8     —    9–11   12–20   —    21–24   ≥25
SpO2 (scale 1)  ≤91   92-93  94-95  ≥96
SpO2 (scale 2)  ≤83  84-85  86-87  88-92  93-94  95-96  ≥97  (on O2 supp.)
Systolic BP     ≤90  91-100 101-110 111-219  —     —    ≥220
Heart rate      ≤40   —    41-50   51-90  91-110 111-130 ≥131
Temp (°C)       ≤35.0  —   35.1-36 36.1-38 38.1-39  —   ≥39.1
AVPU/GCS         —     —     —    Alert   —   Confusion  ≤14
"""

from __future__ import annotations


def _score_resp_rate(rr: float) -> int:
    """Score respiratory rate (breaths/min)."""
    if rr <= 8:
        return 3
    elif rr <= 11:
        return 1
    elif rr <= 20:
        return 0
    elif rr <= 24:
        return 2
    else:  # >= 25
        return 3


def _score_spo2(spo2: float, on_oxygen: bool = False) -> int:
    """Score SpO2 (%).

    Two scales exist: scale 1 (standard) and scale 2 (for patients
    requiring supplemental O2, e.g. COPD with target 88–92%).
    """
    if on_oxygen:
        # Scale 2 (supplemental O2 target 88–92%)
        if spo2 <= 83:    return 3
        elif spo2 <= 85:  return 2
        elif spo2 <= 87:  return 1
        elif spo2 <= 92:  return 0
        elif spo2 <= 94:  return 1
        elif spo2 <= 96:  return 2
        else:             return 3
    else:
        # Scale 1 (standard — air-breathing patients)
        if spo2 <= 91:    return 3
        elif spo2 <= 93:  return 2
        elif spo2 <= 95:  return 1
        else:             return 0


def _score_systolic_bp(sbp: float) -> int:
    """Score systolic blood pressure (mmHg)."""
    if sbp <= 90:       return 3
    elif sbp <= 100:    return 2
    elif sbp <= 110:    return 1
    elif sbp <= 219:    return 0
    else:               return 3  # >= 220


def _score_heart_rate(hr: float) -> int:
    """Score heart rate (beats/min)."""
    # TODO Task 2: Implement heart rate scoring from the table in the module docstring.
    # Boundaries: ≤40→3, 41-50→1, 51-90→0, 91-110→1, 111-130→2, ≥131→3
    raise NotImplementedError("TODO Task 2: implement _score_heart_rate()")


def _score_temperature(temp_c: float) -> int:
    """Score body temperature (°C)."""
    # TODO Task 2: Implement temperature scoring.
    # Boundaries: ≤35.0→3, 35.1-36.0→1, 36.1-38.0→0, 38.1-39.0→1, ≥39.1→2
    raise NotImplementedError("TODO Task 2: implement _score_temperature()")


def _score_consciousness(avpu: str) -> int:
    """Score level of consciousness using AVPU scale.

    AVPU: Alert=0, Voice=3, Pain=3, Unresponsive=3
    New Confusion (C) also scores 3.

    Parameters
    ----------
    avpu : str — one of 'A' (Alert), 'C' (Confusion), 'V' (Voice),
                 'P' (Pain), 'U' (Unresponsive)
    """
    avpu = avpu.strip().upper()
    if avpu == "A":
        return 0
    elif avpu in ("C", "V", "P", "U"):
        return 3
    else:
        raise ValueError(f"Unknown AVPU level: {avpu!r}. Expected A/C/V/P/U.")


def news2_score(
    heart_rate: float,
    resp_rate: float,
    spo2: float,
    systolic_bp: float,
    temperature: float = 37.0,
    avpu: str = "A",
    on_oxygen: bool = False,
) -> tuple[int, str]:
    """Compute the NEWS2 aggregate score and risk level.

    Parameters
    ----------
    heart_rate   : beats per minute (use -1.0 if missing)
    resp_rate    : breaths per minute (use -1.0 if missing)
    spo2         : oxygen saturation % (use -1.0 if missing)
    systolic_bp  : systolic blood pressure mmHg (use -1.0 if missing)
    temperature  : body temperature °C (default 37.0 if missing)
    avpu         : AVPU level string ('A', 'C', 'V', 'P', 'U')
    on_oxygen    : True if patient is on supplemental oxygen

    Returns
    -------
    (score, risk_level)
        score      : int — aggregate NEWS2 score (0–20+)
        risk_level : str — 'low', 'medium', or 'high'

    Notes
    -----
    Missing values (sentinel -1.0) are scored as 0 to avoid false alarms,
    but you should log a warning for downstream monitoring.

    NEWS2 risk stratification:
        0–4  → Low
        5–6  → Medium  (or any single parameter scores 3 → Medium)
        ≥7   → High
    """
    score = 0
    any_3 = False  # flag for any single parameter scoring 3

    def add(parameter_score: int) -> None:
        nonlocal score, any_3
        score += parameter_score
        if parameter_score == 3:
            any_3 = True

    # Score each parameter (skip if sentinel -1.0)
    if resp_rate >= 0:
        add(_score_resp_rate(resp_rate))
    if spo2 >= 0:
        add(_score_spo2(spo2, on_oxygen=on_oxygen))
    if systolic_bp >= 0:
        add(_score_systolic_bp(systolic_bp))
    if heart_rate >= 0:
        # TODO Task 2: call _score_heart_rate when implemented
        pass  # add(_score_heart_rate(heart_rate))
    if temperature >= 0:
        # TODO Task 2: call _score_temperature when implemented
        pass  # add(_score_temperature(temperature))
    add(_score_consciousness(avpu))

    # Determine risk level
    if score >= 7:
        risk = "high"
    elif score >= 5 or any_3:
        risk = "medium"
    else:
        risk = "low"

    return score, risk


def ewma_priority(history: list[float], alpha: float = 0.3) -> float:
    """Compute exponentially weighted moving average of NEWS2 scores.

    A higher EWMA means sustained or worsening patient deterioration.
    The EWMA smooths out transient noise in individual readings.

    Parameters
    ----------
    history : list of recent NEWS2 scores (oldest first)
    alpha   : smoothing factor in (0, 1). Higher = more reactive.
              Recommended: 0.2–0.4 for clinical monitoring.

    Returns
    -------
    float : EWMA priority score (0 = stable, higher = more urgent)

    Example
    -------
    >>> ewma_priority([2, 2, 3, 5, 7], alpha=0.3)
    4.48...
    """
    if not history:
        return 0.0
    if not 0 < alpha <= 1:
        raise ValueError(f"alpha must be in (0, 1], got {alpha}")

    ewma = float(history[0])
    for score in history[1:]:
        ewma = alpha * float(score) + (1.0 - alpha) * ewma
    return ewma


def priority_to_ros_color(priority: float) -> tuple[float, float, float, float]:
    """Map a priority score to an RGBA color for RViz2 markers.

    Returns (r, g, b, a) suitable for std_msgs/ColorRGBA.
      0–4   → green (stable)
      5–6   → amber (watch)
      7+    → red   (urgent)
    """
    if priority >= 7:
        return (1.0, 0.1, 0.1, 1.0)   # red
    elif priority >= 5:
        return (1.0, 0.6, 0.0, 1.0)   # amber
    else:
        return (0.1, 0.8, 0.2, 1.0)   # green
