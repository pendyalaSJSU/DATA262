"""
launch/telemetry_only.launch.py
=================================
Launch just the MIMIC-IV telemetry pipeline and system monitor.
Useful for:
  - Mac / no-GPU users developing Tasks 2 without Isaac Sim
  - Unit testing the telemetry and NEWS2 pipeline independently
  - Demonstrating the data pipeline in a browser via Foxglove Studio

Usage:
  ros2 launch hospital_twin telemetry_only.launch.py

Then open Foxglove Studio and connect to ws://localhost:8765
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, LogInfo
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    args = [
        DeclareLaunchArgument(
            "replay_speed", default_value="5.0",
            description="MIMIC-IV replay speed (5x = faster demo)"),
        DeclareLaunchArgument(
            "use_foxglove", default_value="true",
            description="Start Foxglove WebSocket bridge on :8765"),
    ]

    mimic_node = Node(
        package="hospital_twin",
        executable="mimic_publisher",
        name="mimic_publisher",
        output="screen",
        parameters=[{
            "csv_path": PathJoinSubstitution([
                FindPackageShare("hospital_twin"), "data", "mimic_vitals_sample.csv"
            ]),
            "replay_speed": LaunchConfiguration("replay_speed"),
            "tick_rate_hz": 1.0,
            "ewma_alpha": 0.3,
        }],
    )

    monitor_node = Node(
        package="hospital_twin",
        executable="system_monitor",
        name="system_monitor",
        output="screen",
        parameters=[{
            "room_map_path": PathJoinSubstitution([
                FindPackageShare("hospital_twin"), "data", "patient_room_map.json"
            ]),
        }],
    )

    # Foxglove bridge — connect Studio to ws://localhost:8765
    foxglove_node = Node(
        package="foxglove_bridge",
        executable="foxglove_bridge",
        name="foxglove_bridge",
        parameters=[{"port": 8765, "address": "0.0.0.0"}],
        output="screen",
    )

    info = LogInfo(msg=(
        "\n"
        "Telemetry pipeline started:\n"
        "  Topics: ros2 topic list | grep patient\n"
        "  Foxglove: open foxglove.dev/app → ws://localhost:8765\n"
        "  Import layout: config/foxglove_layout.json\n"
    ))

    return LaunchDescription([
        *args,
        info,
        mimic_node,
        monitor_node,
        foxglove_node,
    ])
