# Hospital Digital Twin — Embodied AI Course Exercise

> **Course:** Embodied AI for Graduate Students  
> **Topic:** Digital Twins in Healthcare using Isaac Sim, Isaac Lab & ROS 2  
> **Estimated time:** 20–30 hours

---

## What you will build

A physics-accurate **digital twin** of a hospital ward where an autonomous mobile robot (AMR)
safely delivers medications to patients. The twin ingests real ICU telemetry from the
**MIMIC-IV** dataset, dynamically re-routes the robot when a patient deteriorates, and streams
all sensor data through **ROS 2** topics — illustrating the complete embodied-AI loop:

```
MIMIC-IV vitals → ROS 2 bridge → Isaac Sim physics → Isaac Lab RL policy
       ↑                                                       ↓
   RViz2 dashboard ←──── priority re-routing ←── patient deterioration alert
```

---

## Hardware Requirements

| Tier | GPU | RAM | Storage | OS |
|------|-----|-----|---------|-----|
| Minimum | NVIDIA RTX 2070 | 16 GB | 50 GB SSD | Ubuntu 22.04 / Win 11 |
| Recommended | NVIDIA RTX 3090/4080+ | 32 GB | 100 GB NVMe | Ubuntu 22.04 LTS |

> **macOS / no-GPU users:** Isaac Sim requires an NVIDIA GPU and does not run natively on
> Apple Silicon. Use [NVIDIA LaunchPad](https://www.nvidia.com/en-us/launchpad/) (free),
> [Lightning.ai](https://lightning.ai) (free A10G tier), or a university lab machine.
> ROS 2 components and the data pipeline can be developed on Mac independently using Docker.

---

## Quick Start

```bash
# 1. Clone this repo
git clone https://github.com/embodied-ai-course/hospital-twin-starter
cd hospital-twin-starter

# 2. Create conda environment
conda env create -f environment.yml
conda activate hospital-twin

# 3. Install ROS 2 package (after sourcing ROS 2)
source /opt/ros/humble/setup.bash
colcon build
source install/setup.bash

# 4. Verify installation
python scripts/verify_install.py

# 5. Run telemetry-only demo (no GPU needed)
ros2 launch hospital_twin telemetry_only.launch.py
```

---

## Installation (step-by-step)

### Step 0 — Cloud GPU option (Mac / no-GPU)

If you don't have a compatible NVIDIA GPU:

- **NVIDIA LaunchPad** (free, registration required): https://www.nvidia.com/en-us/launchpad/
- **Lightning.ai** (free A10G tier): https://lightning.ai
- **Lambda Labs** (~$0.50/hr RTX A6000): https://lambdalabs.com/cloud
- **RunPod** (~$0.39/hr RTX 3090): https://runpod.io

### Step 1 — Install NVIDIA Isaac Sim 4.x (Linux / Windows)

**Option A — Omniverse Launcher (recommended for beginners):**
1. Download from: https://developer.nvidia.com/isaac/sim
2. Create a free NVIDIA account
3. Install Omniverse Launcher → install Isaac Sim 4.x

**Option B — Docker container:**
```bash
docker pull nvcr.io/nvidia/isaac-sim:4.0.0
docker run --gpus all -it --rm \
  -v /tmp/.X11-unix:/tmp/.X11-unix \
  -e DISPLAY=$DISPLAY \
  -v $(pwd):/workspace \
  nvcr.io/nvidia/isaac-sim:4.0.0
```

Full docs: https://docs.omniverse.nvidia.com/isaacsim/latest/installation/index.html

### Step 2 — Install Isaac Lab

```bash
git clone https://github.com/isaac-sim/IsaacLab.git
cd IsaacLab
./isaaclab.sh --install   # creates conda env 'isaaclab'
conda activate isaaclab
cd -  # back to this repo
```

Docs: https://isaac-sim.github.io/IsaacLab/

### Step 3 — Install ROS 2 Humble

**Linux (Ubuntu 22.04) — recommended:**
```bash
sudo apt install software-properties-common
sudo add-apt-repository universe
sudo apt update && sudo apt install curl -y
sudo curl -sSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.key \
  -o /usr/share/keyrings/ros-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] \
  http://packages.ros.org/ros2/ubuntu $(. /etc/os-release && echo $UBUNTU_CODENAME) main" \
  | sudo tee /etc/apt/sources.list.d/ros2.list > /dev/null
sudo apt update
sudo apt install ros-humble-desktop ros-humble-nav2-bringup \
  ros-humble-turtlebot4-simulator python3-colcon-common-extensions
echo "source /opt/ros/humble/setup.bash" >> ~/.bashrc
source ~/.bashrc
```

**Windows:** Use WSL2 with Ubuntu 22.04 (recommended) or see:
https://docs.ros.org/en/humble/Installation/Windows-Install-Binary.html

**macOS:** 
```bash
# Option 1: Docker (recommended)
docker pull osrf/ros:humble-desktop
docker run -it osrf/ros:humble-desktop

# Option 2: Homebrew (unofficial, limited)
brew install ros-humble-desktop
```

### Step 4 — Enable Isaac ROS 2 Bridge

In Isaac Sim:
1. `Window` → `Extensions` → search "ROS2 Bridge" → Enable
2. Restart Isaac Sim

Then install the ROS packages:
```bash
sudo apt install ros-humble-isaac-ros-nitros ros-humble-isaac-ros-common
```

Docs: https://nvidia-isaac-ros.github.io/repositories_and_packages/isaac_ros_nitros/

### Step 5 — Get MIMIC-IV Data

1. Register at: https://physionet.org/register/
2. Complete CITI training (free, ~2 hrs): https://physionet.org/about/citi-course/
3. Request MIMIC-IV access: https://physionet.org/content/mimiciv/3.1/
4. After approval, download `icu/chartevents.csv.gz`

**For this exercise, a pre-filtered 500-patient sample is included in `data/mimic_vitals_sample.csv`.**
You do NOT need the full 35 GB download to complete the exercise.

### Step 6 — Optional: Foxglove Studio

Free cross-platform ROS 2 visualizer (better than RViz2 for dashboards):
- Download: https://foxglove.dev/download
- Connect: `ws://localhost:8765`
- Import layout: `config/foxglove_layout.json`

---

## Repository Structure

```
hospital-twin-starter/
├── hospital_twin/            # Main ROS 2 Python package
│   ├── mimic_publisher.py    # TODO: Task 2 — telemetry ingestion
│   ├── delivery_planner.py   # TODO: Task 3 — priority navigation
│   ├── news2_scorer.py       # TODO: Task 2 (partial impl provided)
│   └── system_monitor.py     # RViz2/Foxglove dashboard node
├── hospital_twin_msgs/        # Custom ROS 2 message definitions
│   └── msg/
│       ├── PatientVitals.msg
│       └── DeliveryTask.msg
├── isaac_lab_envs/           # Isaac Lab RL environment
│   ├── hospital_nav_env.py   # TODO: Task 4 — RL environment
│   ├── hospital_nav_cfg.py   # Environment configuration
│   └── train_ppo.py          # PPO training script
├── isaac_sim_scripts/        # Omniverse Python scripts
│   ├── setup_scene.py        # TODO: Task 1 — scene construction
│   └── spawn_pedestrians.py  # Pedestrian agent spawning
├── assets/
│   └── hospital_ward.usd     # Base Isaac Sim scene
├── config/
│   ├── nav2_params.yaml      # Pre-tuned Nav2 configuration
│   ├── rviz2_hospital.rviz   # RViz2 layout
│   └── foxglove_layout.json  # Foxglove dashboard
├── data/
│   ├── mimic_vitals_sample.csv   # 500-patient MIMIC-IV sample
│   └── patient_room_map.json     # Room → pose mapping
├── launch/
│   ├── full_system.launch.py     # TODO: Task 5
│   ├── nav_only.launch.py
│   └── telemetry_only.launch.py
├── docs/
│   ├── news2_scoring.md
│   └── report_template.md
├── tests/
│   ├── test_news2_scorer.py
│   ├── test_mimic_publisher.py
│   └── test_delivery_planner.py
├── scripts/verify_install.py
├── requirements.txt
├── environment.yml
└── package.xml
```

---

## Running the Full System (Task 5)

```bash
# Terminal 1: Isaac Sim (run from Omniverse)
# Open assets/hospital_ward.usd in Isaac Sim and press Play

# Terminal 2: Full ROS 2 system
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 launch hospital_twin full_system.launch.py

# Terminal 3: Visualization
rviz2 -d config/rviz2_hospital.rviz
# OR: open Foxglove Studio and import config/foxglove_layout.json
```

---

## Running Tests

```bash
pytest tests/ -v
```

---

## Key Resources

| Resource | URL |
|---|---|
| Isaac Sim | https://developer.nvidia.com/isaac/sim |
| Isaac Sim Docs | https://docs.omniverse.nvidia.com/isaacsim/latest/ |
| Isaac Lab | https://github.com/isaac-sim/IsaacLab |
| Isaac Lab Docs | https://isaac-sim.github.io/IsaacLab/ |
| ROS 2 Humble | https://docs.ros.org/en/humble/ |
| Nav2 | https://nav2.org |
| MIMIC-IV | https://physionet.org/content/mimiciv/3.1/ |
| TurtleBot4 | https://github.com/turtlebot/turtlebot4 |
| Foxglove Studio | https://foxglove.dev/download |
| NEWS2 Spec | https://www.rcplondon.ac.uk/projects/outputs/national-early-warning-score-news-2 |
| Embodied AI Survey | https://arxiv.org/abs/2301.01236 |
| Isaac Lab Paper | https://arxiv.org/abs/2310.06825 |

---

## Submission

Submit via course portal:
1. `src/` directory with all completed Python files
2. `rosbags/scenario_demo.bag` (Task 3 recording)  
3. `checkpoints/ppo_hospital_nav/` (Task 4 trained policy)
4. `report/technical_report.pdf` (Task 5, 1500 words)
5. `README_student.md` — your setup notes and any deviations

**Deadline:** See course portal. Late policy: -10 pts/day.
