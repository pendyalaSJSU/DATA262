"""
Installation verification script.
Run: python scripts/verify_install.py
"""

import sys
import time

def check(label, fn):
    try:
        result = fn()
        print(f"  ✓ {label}" + (f": {result}" if result else ""))
        return True
    except Exception as e:
        print(f"  ✗ {label}: {e}")
        return False

print("\n" + "="*55)
print("  Embodied ALife Exercise — Installation Check")
print("="*55)

all_ok = True

print("\n[1] Core packages")
all_ok &= check("numpy",      lambda: __import__("numpy").__version__)
all_ok &= check("scipy",      lambda: __import__("scipy").__version__)
all_ok &= check("matplotlib", lambda: __import__("matplotlib").__version__)
all_ok &= check("mujoco",     lambda: __import__("mujoco").__version__)

print("\n[2] MuJoCo model loading")
import mujoco, numpy as np
from pathlib import Path

xml_path = Path(__file__).parent.parent / "configs" / "quadruped_starter.xml"
all_ok &= check("Starter XML exists", lambda: str(xml_path) if xml_path.exists() else (_ for _ in ()).throw(FileNotFoundError(xml_path)))
all_ok &= check("XML loads in MuJoCo", lambda: f"{mujoco.MjModel.from_xml_path(str(xml_path)).nq} DOFs")

print("\n[3] Simulation performance")
def perf_test():
    model = mujoco.MjModel.from_xml_path(str(xml_path))
    data  = mujoco.MjData(model)
    t0 = time.time()
    for _ in range(1000):
        mujoco.mj_step(model, data)
    elapsed = time.time() - t0
    if elapsed > 5.0:
        raise RuntimeError(f"Too slow: {elapsed:.2f}s for 1000 steps (expected <2s)")
    return f"1000 steps in {elapsed:.3f}s ({1000/elapsed:.0f} steps/sec)"
all_ok &= check("Simulation speed", perf_test)

print("\n[4] Viewer availability")
def viewer_test():
    import mujoco.viewer
    return "available (run with render=True to open)"
all_ok &= check("MuJoCo viewer", viewer_test)

print("\n[5] Optional packages")
check("jupyter",  lambda: __import__("jupyter_core").__version__)
check("cma (bonus)", lambda: __import__("cma").__version__)
check("plotly (bonus)", lambda: __import__("plotly").__version__)

print("\n" + "="*55)
if all_ok:
    print("  ✓ All checks passed — ready to start the exercise!")
else:
    print("  ✗ Some checks failed — see above for details.")
    print("    Try: pip install mujoco --upgrade")
print("="*55 + "\n")

sys.exit(0 if all_ok else 1)
