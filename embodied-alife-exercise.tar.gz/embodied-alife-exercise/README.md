# Embodied ALife Exercise
## Morphogenetic Adaptation in Disaster Response Robots

**Course:** Embodied AI | **Module:** Artificial Life  
**Estimated Time:** 20–30 hours across 2 weeks  
**Difficulty:** Graduate level

---

## Table of Contents
1. [Overview & Motivation](#overview)
2. [Learning Outcomes](#learning-outcomes)
3. [Background Reading](#background-reading)
4. [Installation](#installation)
5. [Repository Structure](#repository-structure)
6. [Exercise Parts](#exercise-parts)
7. [Grading Rubric](#grading-rubric)
8. [Submission Instructions](#submission)
9. [Resources & References](#references)

---

## Overview & Motivation <a name="overview"></a>

> *"Intelligence cannot be disembodied."* — Rodney Brooks (1991)

Imagine a disaster-response robot deployed in a collapsed building. Unlike a factory robot, it cannot rely on a pre-surveyed map, engineered terrain, or fixed body plan. It must:

- **Adapt its gait** to rubble, slopes, and gaps
- **Evolve efficient body proportions** for the specific disaster environment  
- **Respond reflexively** to obstacles without central computation  
- **Cooperate emergently** with other robots through local sensing alone

This is not science fiction — it is the core agenda of **Artificial Life (ALife)** applied to robotics.

In this exercise, you will implement a full ALife pipeline using **MuJoCo** — one of the world's most physically accurate simulators — to study:

| ALife Concept | Implementation |
|---|---|
| Morphological Computation | Passive tendons doing work the controller doesn't |
| Evolutionary Robotics | (1+λ)-ES co-evolving body geometry + CPG parameters |
| Sensorimotor Loops | Touch → stumble reflex → gait adaptation |
| Homeostasis | Energy budget constraining evolutionary fitness |
| Emergence | Collective traffic patterns from individual local rules |

---

## Learning Outcomes <a name="learning-outcomes"></a>

By completing this exercise, you will be able to:

1. **[Part 1]** Build procedurally generated MuJoCo XML models and explain how morphology affects dynamics
2. **[Part 2]** Implement a biologically-inspired CPG controller using Kuramoto oscillator coupling
3. **[Part 3]** Generate and embed procedural terrain heightfields in MuJoCo scenes  
4. **[Part 4]** Design and run an evolutionary robotics experiment, interpret fitness landscapes
5. **[Part 5]** Simulate multi-agent systems and identify emergent collective behaviors
6. **[Part 6]** Produce rigorous scientific visualizations of ALife experiments

---

## Background Reading <a name="background-reading"></a>

**Required (read before starting):**
- Brooks, R.A. (1991). *Intelligence Without Representation*. Artificial Intelligence, 47, 139–159. [PDF](https://people.csail.mit.edu/brooks/papers/representation.pdf)
- Ijspeert, A.J. (2008). *Central Pattern Generators for Locomotion Control*. Neural Networks, 21(4), 642–653. [PDF](https://infoscience.epfl.ch/record/128847)
- Sims, K. (1994). *Evolving Virtual Creatures*. SIGGRAPH. [PDF](https://www.karlsims.com/papers/siggraph94.pdf)

**Recommended:**
- Pfeifer, R., & Bongard, J. (2006). *How the Body Shapes the Way We Think.* MIT Press. [Book](https://mitpress.mit.edu/9780262162395/)
- Bongard, J. (2013). *Evolutionary Robotics*. Communications of the ACM, 56(8). [PDF](https://dl.acm.org/doi/10.1145/2493883)
- MuJoCo Documentation: [mujoco.readthedocs.io](https://mujoco.readthedocs.io)
- MuJoCo Python Tutorial: [github.com/google-deepmind/mujoco/tree/main/python](https://github.com/google-deepmind/mujoco/tree/main/python)

**ALife Community:**
- ALIFE Conference Proceedings: [alife.org/conference](https://alife.org/conference/)
- Artificial Life Journal (MIT Press): [direct.mit.edu/artl](https://direct.mit.edu/artl)

---

## Installation <a name="installation"></a>

### Prerequisites (All Platforms)
- [Miniconda](https://docs.conda.io/en/latest/miniconda.html) or [Anaconda](https://www.anaconda.com/download)
- Git: [git-scm.com](https://git-scm.com)

### Step 1 — Clone the Repository

```bash
git clone https://github.com/[YOUR_COURSE_REPO]/embodied-alife-exercise.git
cd embodied-alife-exercise
```

### Step 2 — Create the Conda Environment

```bash
conda env create -f environment.yml
conda activate embodied-alife
```

### Step 3 — Install MuJoCo Python Bindings

MuJoCo 3.x is bundled with the `mujoco` Python package — **no separate binary download needed**.

```bash
pip install mujoco
```

### Step 4 — Verify Installation

```bash
python -c "import mujoco; print(f'MuJoCo {mujoco.__version__} OK')"
python -c "import mujoco.viewer; print('Viewer OK')"
```

---

### Platform-Specific Notes

#### macOS (Intel & Apple Silicon)

```bash
# Apple Silicon (M1/M2/M3): MuJoCo supports native ARM
# If you see OpenGL errors, install:
brew install glfw

# For headless rendering (no display):
export MUJOCO_GL=osmesa
# or for EGL:
export MUJOCO_GL=egl
```

On macOS, the interactive viewer uses Metal/OpenGL. You may need to grant terminal
access to the screen in System Settings → Privacy & Security → Screen Recording.

#### Windows 10/11

```bash
# Use Anaconda Prompt or PowerShell
conda env create -f environment.yml
conda activate embodied-alife
pip install mujoco

# Windows may need Visual C++ Redistributable:
# https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist

# For headless/CI use:
$env:MUJOCO_GL="osmesa"
```

On Windows, the viewer window opens in a separate process. If you see a black window,
update your graphics drivers.

#### Linux (Ubuntu 20.04 / 22.04)

```bash
# Install system dependencies for rendering
sudo apt-get install -y \
    libgl1-mesa-dev \
    libgl1-mesa-glx \
    libglew-dev \
    libosmesa6-dev \
    patchelf

conda env create -f environment.yml
conda activate embodied-alife
pip install mujoco

# For headless servers (no display):
export MUJOCO_GL=osmesa
# or for GPU-accelerated headless:
export MUJOCO_GL=egl
```

---

### Step 5 — Verify with Starter Model

```bash
python scripts/verify_install.py
```

Expected output:
```
✓ MuJoCo 3.x installed
✓ Starter XML loads successfully  
✓ 1000-step simulation runs in <2s
✓ Viewer available (close to continue)
```

### Step 6 — Register Jupyter Kernel

```bash
python -m ipykernel install --user --name embodied-alife --display-name "Python 3 (embodied-alife)"
jupyter lab notebooks/
```

---

## Repository Structure <a name="repository-structure"></a>

```
embodied-alife-exercise/
│
├── README.md                  ← You are here
├── environment.yml            ← Conda environment spec
│
├── src/
│   └── environment.py         ← ★ YOUR MAIN WORK FILE ★
│                                  (skeleton code with TODOs)
│
├── configs/
│   └── quadruped_starter.xml  ← Reference MuJoCo XML (study this!)
│
├── notebooks/
│   └── 01_exploration.ipynb   ← Guided exploration & prototyping
│
├── tests/
│   └── test_exercise.py       ← Test suite (run to check your work)
│
├── scripts/
│   └── verify_install.py      ← Installation verification
│
└── results/                   ← Output plots go here (auto-created)
```

**Your primary deliverable:** `src/environment.py` with all TODOs implemented.

---

## Exercise Parts <a name="exercise-parts"></a>

### Part 1 — Procedural Morphogenesis (25 pts)
**Learning Outcome 1 | Files: `src/environment.py` → `QuadrupedMorphology`**

**Concept:** In biological development, a single genome encodes not a fixed body,
but a growth *process* (morphogenesis). Karl Sims' 1994 landmark work showed that
co-evolving body structure with neural controllers produces richer behaviors.

**Tasks:**
1. **[1a, 12 pts]** Implement `build_xml()` to generate valid MuJoCo XML from genome parameters
   - 4 legs with 3 DOFs each (hip-abduct, hip-flex, knee)
   - All sensors: 4 touch (feet), IMU (gyro + accel + quat), 2 rangefinders
   - Passive tendons coupling hip→knee within each leg
   - Verify with: `pytest tests/ -k "test_xml_loads"`

2. **[1b, 8 pts]** Implement `mutate()` for evolutionary variation
   - Gaussian perturbation of each genome parameter
   - Clamp to valid ranges (all positive, reasonable physical bounds)
   - Verify with: `pytest tests/ -k "test_mutate"`

3. **[1c, 5 pts]** Show that genome changes affect physical size
   - Load two morphologies with extreme leg lengths, compare MuJoCo model properties
   - Document in your notebook

**Key resources:**
- MuJoCo XML reference: [mujoco.readthedocs.io/en/latest/XMLreference.html](https://mujoco.readthedocs.io/en/latest/XMLreference.html)
- Study `configs/quadruped_starter.xml` carefully first!

---

### Part 2 — CPG Controller (25 pts)
**Learning Outcome 2 | Files: `src/environment.py` → `CPGController`**

**Concept:** Animals use Central Pattern Generators — spinal circuits that produce
rhythmic motor patterns WITHOUT continuous sensory input. Sensory feedback modulates
(not creates) the rhythm. This decentralizes control: the spinal cord handles
rhythm, the brain handles steering.

**Tasks:**
1. **[2a, 12 pts]** Implement `_build_coupling_matrix()` and `step()`
   - Kuramoto dynamics: `dφ/dt = ω + Σ K·sin(φⱼ - φᵢ - Δᵢⱼ)`
   - Support all 4 gaits: trot, walk, bound, pace
   - Verify with: `pytest tests/ -k "test_oscillation_is_periodic"`

2. **[2b, 7 pts]** Implement `stumble_reflex()`
   - High foot contact during expected swing → increase lift amplitude
   - Test: apply high contact force to one foot, observe amplitude increase

3. **[2c, 6 pts]** Implement `get_metabolic_cost()`
   - Mechanical power: `P = Σ |τᵢ · ωᵢ|`
   - Track cumulative work across an episode

**Key resources:**
- Ijspeert (2008) CPG paper (required reading above)
- Kuramoto model: [Wikipedia](https://en.wikipedia.org/wiki/Kuramoto_model)
- Prototype in `notebooks/01_exploration.ipynb` Cell 3 first!

---

### Part 3 — Terrain Generator (10 pts)
**Learning Outcome 3 | Files: `src/environment.py` → `TerrainGenerator`**

**Concept:** Terrain is the selective environment. ALife teaches that behavior
cannot be understood without its environment — a robot evolved on flat ground
will fail on rubble (and vice versa).

**Tasks:**
1. **[3a, 6 pts]** Implement at least 2 non-trivial terrain types:
   - `'rubble'`: Multi-octave fractal noise (see notebook Cell 3 for hint)
   - `'slope'` OR `'gaps'`: Your choice

2. **[3b, 4 pts]** Implement `embed_in_xml()` to inject height data into XML

**Key resources:**
- MuJoCo heightfield: [docs](https://mujoco.readthedocs.io/en/latest/XMLreference.html#asset-hfield)
- `scipy.ndimage.gaussian_filter` for smooth noise
- Prototype in notebook first

---

### Part 4 — Evolutionary Optimization (20 pts)
**Learning Outcome 4 | Files: `src/environment.py` → `EvolutionaryOptimizer`**

**Concept:** Evolutionary robotics lets selection — rather than engineering —
discover effective body-brain configurations. The fitness function embodies
the selective pressure (here: efficiency over terrain, not just speed).

**Tasks:**
1. **[4a, 10 pts]** Implement `evaluate_individual()`:
   - Full MuJoCo simulation loop (sensor read → CPG step → set ctrl → mj_step)
   - Track: distance traveled, metabolic cost, fall detection, step timing

2. **[4b, 10 pts]** Implement `run_generation()` and `evolve()`:
   - (1+λ)-ES: mutate parent λ times, evaluate all, select best
   - Log per-generation: best fitness, mean fitness, std fitness
   - Save checkpoint every 10 generations

**Suggested workflow:**
```
Run mode: python src/environment.py test   (1 gen, 3s episodes — ~2 min)
Run mode: python src/environment.py demo   (render pre-evolved genome)
Run mode: python src/environment.py full   (50 gens — ~30 min with pop=20)
```

---

### Part 5 — Multi-Agent Collective Behavior (10 pts)
**Learning Outcome 5 | Files: `src/environment.py` → `SwarmSimulation`**

**Concept:** When multiple agents share an environment, collective phenomena
emerge that cannot be predicted from studying individuals alone.

**Tasks:**
1. **[5a, 6 pts]** Implement `build_multi_agent_xml()` — multiple robots in one scene
2. **[5b, 4 pts]** Implement `run()` and identify at least one emergent behavior

**What to look for:**
- Do agents form traffic patterns without explicit coordination?
- Do they deadlock? How often?
- How does spacing evolve over time?

---

### Part 6 — Analysis & Visualization (10 pts)
**Learning Outcome 6 | Files: `src/environment.py` → `ExperimentAnalyzer`**

Implement all 5 required plots. Each must be saved as PNG in `results/` and
included in your report with interpretation.

**Required figures:**
1. **Fitness curve**: Mean ± std per generation (with confidence band)
2. **Gait diagram**: Foot contact ethogram (4 legs × time, binary black/white)
3. **Morphology comparison**: Evolved vs default genome (bar chart)
4. **Fitness landscape**: 2D heatmap over 2 morphological parameters
5. **Phase portrait**: CPG oscillator phases over time (polar plot)

---

## Grading Rubric <a name="grading-rubric"></a>

### Overall Distribution

| Part | Component | Points | Weight |
|------|-----------|--------|--------|
| 1 | Morphogenesis (build_xml + mutate) | 25 | 25% |
| 2 | CPG Controller (step + reflex + cost) | 25 | 25% |
| 3 | Terrain Generator | 10 | 10% |
| 4 | Evolutionary Optimizer | 20 | 20% |
| 5 | Multi-Agent Simulation | 10 | 10% |
| 6 | Analysis & Visualization | 10 | 10% |
| **Total** | | **100** | **100%** |

---

### Detailed Rubric

#### Part 1: Morphogenesis (25 pts)

| Criterion | Excellent (Full) | Proficient (75%) | Developing (50%) | Insufficient (0%) |
|-----------|-----------------|-----------------|-----------------|-------------------|
| **XML correctness** (12 pts) | XML loads in MuJoCo, all sensors present, 12 actuators, passive tendons functional | XML loads, most sensors present, minor issues | XML loads but missing sensors or actuators | XML fails to load OR is hardcoded (not from genome) |
| **Mutation** (8 pts) | Gaussian mutation implemented, all parameters stay positive, sigma-scaling correct | Mutation works but may occasionally produce invalid params | Mutation present but doesn't respect bounds | Not implemented |
| **Genome→morphology** (5 pts) | Clearly demonstrates genome affects physical dimensions with evidence | Shows some effect | Cursory demonstration | Not addressed |

#### Part 2: CPG Controller (25 pts)

| Criterion | Excellent | Proficient | Developing | Insufficient |
|-----------|-----------|------------|------------|--------------|
| **Kuramoto dynamics** (12 pts) | Correct coupling matrix for all 4 gaits, phases converge to targets, output is bounded | 2+ gaits correct, convergence demonstrated | 1 gait working | Hardcoded sinusoid, not a CPG |
| **Stumble reflex** (7 pts) | Biologically plausible reflex: swing-phase detection + amplitude modulation + evidence it helps on terrain | Reflex present, partially effective | Basic threshold-based reflex | Not implemented |
| **Metabolic cost** (6 pts) | Physically motivated formula (power = τ·ω), tracked cumulatively, used in fitness | Correct formula, minimal use | Present but incorrect formula | Not implemented |

#### Part 3: Terrain (10 pts)

| Criterion | Excellent | Proficient | Developing | Insufficient |
|-----------|-----------|------------|------------|--------------|
| **Terrain quality** (6 pts) | 2+ non-trivial terrains, fractal noise for rubble, visually varied, MuJoCo compatible | 2 terrains, one is non-trivial | Only 1 non-trivial terrain | Only flat terrain |
| **XML embedding** (4 pts) | embed_in_xml works, correct hfield format, terrain visible in simulation | Works but minor issues | Partial implementation | Not implemented |

#### Part 4: Evolutionary Optimizer (20 pts)

| Criterion | Excellent | Proficient | Developing | Insufficient |
|-----------|-----------|------------|------------|--------------|
| **Simulation loop** (10 pts) | Complete sensor→CPG→ctrl→step loop, correct API usage, fall detection, timing | Loop works, minor sensor/fall issues | Loop runs but ignores sensors or fall | Loop crashes or not implemented |
| **Evolution** (10 pts) | (1+λ)-ES correct, fitness increases over generations (demonstrated), checkpointing | Selection logic correct, some improvement | Evolution runs but fitness doesn't improve | Not implemented |

#### Part 5: Multi-Agent (10 pts)

| Criterion | Excellent | Proficient | Developing | Insufficient |
|-----------|-----------|------------|------------|--------------|
| **Implementation** (6 pts) | Multiple robots in one scene, correct contact handling, independent CPGs | Multiple robots, some issues | 2 robots working partially | Not implemented |
| **Analysis** (4 pts) | Identifies and explains ≥1 emergent behavior with data | Notes behavior, limited data | Notes behavior, no data | No analysis |

#### Part 6: Visualizations (10 pts)

All 5 required plots (2 pts each):
- **Fitness curve**: Has confidence band, correctly labeled
- **Gait diagram**: Ethogram format (binary, 4 rows, time axis)
- **Morphology comparison**: Clearly shows evolved vs default
- **Fitness landscape**: 2D heatmap with axis labels, colorbar
- **Phase portrait**: Polar or Cartesian, shows phase evolution

---

### Bonus Opportunities (+15 pts max)

| Bonus | Points | Description |
|-------|--------|-------------|
| CMA-ES | +5 | Replace (1+λ)-ES with CMA-ES (use `cma` package) |
| Morphological crossover | +3 | Implement uniform crossover between parents |
| Stigmergy | +4 | Implement pheromone grid for multi-agent coordination |
| Sim-to-real analysis | +3 | Discuss what would need to change to deploy on real hardware |

---

## Submission Instructions <a name="submission"></a>

Submit a ZIP file containing:
```
[your_name]_embodied_alife/
├── src/environment.py          ← Completed implementation
├── notebooks/01_exploration.ipynb  ← Executed with all outputs
├── results/                    ← All 5 required plots (PNG)
│   ├── fitness_curve.png
│   ├── gait_diagram.png
│   ├── morphology_comparison.png
│   ├── fitness_landscape.png
│   └── phase_portrait.png
└── report.pdf                  ← 4–6 page lab report (see below)
```

### Lab Report Guidelines (4–6 pages)

1. **Introduction** (0.5p): What ALife concepts does this exercise address?
2. **Methods** (1p): Key implementation decisions for CPG, evolution, terrain
3. **Results** (2–3p): All 5 figures with interpretation, evolution outcomes
4. **Discussion** (1p): Answer the 5 reflection questions from the notebook
5. **References**: Cite all 3 required papers + any others used

---

## Resources & References <a name="references"></a>

### Software
- **MuJoCo**: [mujoco.org](https://mujoco.org) | [GitHub](https://github.com/google-deepmind/mujoco)
- **MuJoCo Python docs**: [mujoco.readthedocs.io](https://mujoco.readthedocs.io/en/latest/python.html)
- **Conda**: [docs.conda.io](https://docs.conda.io)

### ALife & Evolutionary Robotics
- Karl Sims' original creatures: [karlsims.com/evolved-virtual-creatures.html](https://www.karlsims.com/evolved-virtual-creatures.html)
- OpenAI's evolutionary strategies: [arxiv.org/abs/1703.03864](https://arxiv.org/abs/1703.03864)
- Soft Actor-Critic on locomotion: [arxiv.org/abs/1801.01290](https://arxiv.org/abs/1801.01290)

### CPG & Locomotion
- Ijspeert lab resources: [biorob.epfl.ch](https://www.epfl.ch/labs/biorob/)
- Kimura et al. adaptive CPG: [IEEE 2007](https://ieeexplore.ieee.org/document/4339274)

### Disaster Robotics Context
- DARPA Robotics Challenge: [darpa.mil/program/darpa-robotics-challenge](https://www.darpa.mil/program/darpa-robotics-challenge)
- RHex robot (ALife-inspired): [kodlab.seas.upenn.edu/robots/rhex/](http://kodlab.seas.upenn.edu/robots/rhex/)

### MuJoCo Examples to Study
- Ant environment (OpenAI Gym): [github.com/openai/gym/blob/master/gym/envs/mujoco/ant_v4.py](https://github.com/openai/gym/blob/master/gym/envs/mujoco/ant_v4.py)
- MuJoCo Python colab: [colab.research.google.com/github/deepmind/mujoco/blob/main/python/tutorial.ipynb](https://colab.research.google.com/github/deepmind/mujoco/blob/main/python/tutorial.ipynb)

---

*Questions? Post to the course forum. Tag issues `[embodied-alife]`.*
