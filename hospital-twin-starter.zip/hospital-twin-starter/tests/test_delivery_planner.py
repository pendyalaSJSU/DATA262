"""
tests/test_delivery_planner.py
================================
Unit tests for the DeliveryPlanner priority queue and preemption logic.
Tests the pure-Python data structures without requiring ROS 2 or Nav2.

Run: pytest tests/test_delivery_planner.py -v
"""

import sys, os, types, pytest

# Stub out all ROS 2 / Nav2 imports so tests run without ROS 2 installed
for mod in [
    "rclpy", "rclpy.node", "rclpy.qos",
    "nav2_simple_commander", "nav2_simple_commander.robot_navigator",
    "geometry_msgs", "geometry_msgs.msg",
    "std_msgs", "std_msgs.msg",
    "hospital_twin_msgs", "hospital_twin_msgs.msg",
]:
    sys.modules.setdefault(mod, types.ModuleType(mod))

# Provide stub TaskResult enum
nav2_stub = sys.modules["nav2_simple_commander.robot_navigator"]
if not hasattr(nav2_stub, "TaskResult"):
    class _TR:
        SUCCEEDED = 1; FAILED = 2; CANCELED = 3
    nav2_stub.TaskResult = _TR
    nav2_stub.BasicNavigator = object

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


# ── Import the dataclass without instantiating the ROS node ──────────────────
from hospital_twin.delivery_planner import DeliveryTask


# ── DeliveryTask ordering ─────────────────────────────────────────────────────

class TestDeliveryTaskOrdering:
    """Priority queue should order tasks highest-priority first."""

    def test_higher_priority_sorts_first(self):
        low  = DeliveryTask(patient_id="p001", priority=1.0)
        high = DeliveryTask(patient_id="p002", priority=8.0)
        queue = sorted([low, high])
        assert queue[0].patient_id == "p002"  # highest first

    def test_equal_priority_stable(self):
        a = DeliveryTask(patient_id="p001", priority=5.0)
        b = DeliveryTask(patient_id="p002", priority=5.0)
        queue = sorted([a, b])
        # Both are valid; just ensure no crash
        assert len(queue) == 2

    def test_queue_of_five(self):
        tasks = [
            DeliveryTask(patient_id=f"p00{i}", priority=float(i))
            for i in range(1, 6)
        ]
        sorted_tasks = sorted(tasks)
        # p005 (priority 5.0) should be first
        assert sorted_tasks[0].patient_id == "p005"
        # p001 (priority 1.0) should be last
        assert sorted_tasks[-1].patient_id == "p001"

    def test_zero_priority_last(self):
        zero = DeliveryTask(patient_id="p001", priority=0.0)
        mid  = DeliveryTask(patient_id="p002", priority=3.5)
        queue = sorted([zero, mid])
        assert queue[0].patient_id == "p002"


# ── Preemption logic (pure Python, no ROS 2) ──────────────────────────────────

class TestPreemptionLogic:
    """Simulate the preemption decision without Nav2."""

    def _should_preempt(
        self,
        current_priority: float,
        incoming_priority: float,
        threshold: float = 3.0,
    ) -> bool:
        """Replicate the preemption condition from delivery_planner.py."""
        return (incoming_priority - current_priority) >= threshold

    def test_large_delta_triggers_preemption(self):
        assert self._should_preempt(2.0, 8.0, threshold=3.0) is True

    def test_small_delta_no_preemption(self):
        assert self._should_preempt(5.0, 6.0, threshold=3.0) is False

    def test_exact_threshold_triggers(self):
        assert self._should_preempt(4.0, 7.0, threshold=3.0) is True

    def test_lower_priority_no_preemption(self):
        """A lower-priority interrupt should never preempt."""
        assert self._should_preempt(7.0, 2.0, threshold=3.0) is False

    def test_equal_priority_no_preemption(self):
        assert self._should_preempt(5.0, 5.0, threshold=3.0) is False

    def test_custom_threshold(self):
        assert self._should_preempt(3.0, 5.0, threshold=1.0) is True
        assert self._should_preempt(3.0, 5.0, threshold=5.0) is False


# ── Room map loading ───────────────────────────────────────────────────────────

class TestRoomMapLoading:
    def test_room_map_json_valid(self):
        import json
        path = os.path.join(
            os.path.dirname(__file__), "..", "data", "patient_room_map.json"
        )
        with open(path) as f:
            room_map = json.load(f)
        assert "p001" in room_map
        assert "x" in room_map["p001"]
        assert "y" in room_map["p001"]

    def test_all_patients_have_rooms(self):
        import json
        path = os.path.join(
            os.path.dirname(__file__), "..", "data", "patient_room_map.json"
        )
        with open(path) as f:
            room_map = json.load(f)
        for pid in ["p001", "p002", "p003", "p004", "p005"]:
            assert pid in room_map, f"Missing room for {pid}"

    def test_missing_map_uses_fallback(self):
        """If room map file missing, fallback positions are used (not a crash)."""
        patient_ids = ["p001", "p002", "p003", "p004", "p005"]
        fallback = {
            pid: {"x": 2.0 + i * 3.5, "y": 1.0, "yaw": 0.0}
            for i, pid in enumerate(patient_ids)
        }
        assert len(fallback) == 5
        assert fallback["p001"]["x"] == pytest.approx(2.0)
