"""
hospital_twin
=============
ROS 2 package for the Hospital Digital Twin exercise.

Embodied AI Graduate Course — NVIDIA Isaac Sim + Isaac Lab + ROS 2 Humble
"""

__version__ = "0.1.0"
__author__  = "Embodied AI Course"
