"""
isaac_sim_scripts/setup_scene.py
==================================
Task 1: Set up the hospital ward scene in Isaac Sim and configure
the TurtleBot4 with lidar, RGB-D camera, and IMU sensors.

Run this script from within Isaac Sim via:
  Isaac Sim → Script Editor → Open → setup_scene.py → Run

Or from the command line (headless):
  ./python.sh isaac_sim_scripts/setup_scene.py

References
----------
Isaac Sim USD API:  https://docs.omniverse.nvidia.com/isaacsim/latest/manual_standalone_python.html
URDF importer:      https://docs.omniverse.nvidia.com/isaacsim/latest/ext_omni_isaac_urdf.html
ROS 2 Bridge:       https://docs.omniverse.nvidia.com/isaacsim/latest/ros2_tutorials/index.html
TurtleBot4 URDF:    https://github.com/turtlebot/turtlebot4
"""

# ── Isaac Sim / Omniverse imports ─────────────────────────────────────────────
# These only work inside an Isaac Sim Python environment
try:
    import omni
    import omni.usd
    from omni.isaac.core import World
    from omni.isaac.core.utils.stage import add_reference_to_stage
    from omni.isaac.core.utils.nucleus import get_assets_root_path
    from omni.isaac.core.robots import Robot
    from pxr import UsdGeom, Gf, UsdPhysics
except ImportError:
    raise ImportError(
        "This script must be run inside Isaac Sim's Python environment.\n"
        "Launch via: Isaac Sim → Script Editor → Run\n"
        "Or: ./python.sh isaac_sim_scripts/setup_scene.py"
    )

import carb


def setup_hospital_scene() -> None:
    """Main scene setup function. Call from Isaac Sim Script Editor."""

    # ── Step 1: Create/open the Isaac Sim world ───────────────────────────────
    world = World(stage_units_in_meters=1.0)
    world.scene.add_default_ground_plane()

    # ── Step 2: Load hospital ward USD ────────────────────────────────────────
    # The provided hospital_ward.usd contains walls, floors, doors, and room markers.
    # Students may also use any hospital environment from the Omniverse Asset Store (free).
    hospital_usd = "omniverse://localhost/Projects/hospital_ward/hospital_ward.usd"

    # TODO Task 1: Uncomment and verify the path to your hospital USD.
    # Option A — Local file:
    # hospital_usd = str(Path(__file__).parent.parent / "assets" / "hospital_ward.usd")
    # Option B — Omniverse Nucleus (requires local Nucleus server):
    # hospital_usd = "omniverse://localhost/Projects/hospital_ward.usd"
    # Option C — NVIDIA Assets (requires NVIDIA account + Nucleus):
    # hospital_usd = get_assets_root_path() + "/Isaac/Environments/Hospital/hospital.usd"

    print(f"[setup_scene] Loading hospital environment from:\n  {hospital_usd}")
    # TODO Task 1: Uncomment when path is confirmed
    # add_reference_to_stage(usd_path=hospital_usd, prim_path="/World/Hospital")

    # ── Step 3: Import TurtleBot4 URDF ────────────────────────────────────────
    # Download URDF: https://github.com/turtlebot/turtlebot4
    # Then use the URDF importer extension to convert to USD.
    # Extension: Window → Extensions → "URDF Importer"

    # TODO Task 1: Import the TurtleBot4 URDF.
    # The URDF importer can be called programmatically:
    #
    # from omni.isaac.urdf import _urdf
    # urdf_interface = _urdf.acquire_urdf_interface()
    # import_config = _urdf.ImportConfig()
    # import_config.merge_fixed_joints = True
    # import_config.fix_base = False
    # import_config.import_inertia_tensor = True
    # import_config.distance_scale = 1.0
    # import_config.density = 0.0
    # import_config.default_drive_type = _urdf.UrdfJointTargetType.JOINT_DRIVE_VELOCITY
    # import_config.default_drive_strength = 1047.19751
    # import_config.default_position_drive_damping = 52.35988
    # import_config.convex_decomp = False
    # import_config.self_collision = False
    # import_config.up_axis = _urdf.UrdfUpAxis.Z
    #
    # urdf_path = "/path/to/turtlebot4/turtlebot4.urdf"
    # result, prim_path = omni.kit.commands.execute(
    #     "URDFParseAndImportFile",
    #     urdf_path=urdf_path,
    #     import_config=import_config,
    #     dest_path="/World/TurtleBot4",
    # )
    # if result:
    #     print(f"[setup_scene] TurtleBot4 imported at: {prim_path}")
    # else:
    #     carb.log_error("URDF import failed. Check the URDF path and extension.")

    print("[setup_scene] TODO Task 1: Uncomment TurtleBot4 URDF import block.")

    # ── Step 4: Configure ROS 2 Bridge sensors ────────────────────────────────
    # The ROS 2 Bridge extension must be enabled in Isaac Sim first:
    # Window → Extensions → search "ROS2 Bridge" → Enable → Restart

    # TODO Task 1: Add the following sensors via the Isaac Sim GUI or API:
    #
    # A) Lidar (2D):
    #    - Prim path: /World/TurtleBot4/base_link/lidar
    #    - Type: Rotating Lidar PhysX
    #    - Range: 0.15–12 m, 360°, 720 samples/rotation at 10 Hz
    #    - ROS 2 topic: /scan (sensor_msgs/LaserScan)
    #
    # B) RGB-D Camera:
    #    - Prim path: /World/TurtleBot4/base_link/camera
    #    - Resolution: 640×480, FoV: 69.4°, depth range: 0.1–10 m
    #    - ROS 2 topics: /camera/color/image_raw, /camera/depth/image_raw
    #                    /camera/color/camera_info
    #
    # C) IMU:
    #    - Prim path: /World/TurtleBot4/base_link/imu
    #    - Publish rate: 100 Hz
    #    - ROS 2 topic: /imu/data (sensor_msgs/Imu)
    #
    # D) Odometry:
    #    - ROS 2 topic: /odom (nav_msgs/Odometry)
    #    - TF: odom → base_link
    #
    # For programmatic sensor creation, see:
    # https://docs.omniverse.nvidia.com/isaacsim/latest/ros2_tutorials/tutorial_ros2_custom_message.html

    # ── Step 5: Set initial robot pose ───────────────────────────────────────
    # TODO Task 1: Position the robot at the charging station (corridor start)
    # robot_prim = world.scene.get_object("TurtleBot4")
    # if robot_prim:
    #     robot_prim.set_world_pose(
    #         position=np.array([0.5, 0.0, 0.05]),  # charging station (x, y, z)
    #         orientation=np.array([1, 0, 0, 0]),   # quaternion (w, x, y, z)
    #     )

    # ── Step 6: Play the simulation ──────────────────────────────────────────
    world.reset()
    print("\n[setup_scene] Scene setup complete.")
    print("[setup_scene] ✓ Press PLAY in Isaac Sim to start physics simulation.")
    print("[setup_scene] ✓ Then verify sensor topics:")
    print("[setup_scene]   ros2 topic list | grep -E '/scan|/imu|/odom|/camera'")


# ── Scene validation helper ───────────────────────────────────────────────────

def validate_ros2_topics(expected_topics: list[str]) -> None:
    """Check that expected ROS 2 topics are being published.

    Run this after pressing Play in Isaac Sim.
    Requires rclpy in the same Python environment.
    """
    import subprocess, time
    time.sleep(2.0)  # wait for ROS 2 bridge to initialise

    result = subprocess.run(
        ["ros2", "topic", "list"], capture_output=True, text=True, timeout=10
    )
    active = result.stdout.splitlines()

    print("\n[validate] Checking ROS 2 topics:")
    all_ok = True
    for topic in expected_topics:
        ok = topic in active
        status = "✓" if ok else "✗ MISSING"
        print(f"  {status}  {topic}")
        all_ok = all_ok and ok

    if all_ok:
        print("\n[validate] All expected topics are active. Task 1 complete!")
    else:
        print("\n[validate] Some topics missing. Check ROS 2 Bridge extension is enabled.")


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    setup_hospital_scene()

    # After pressing Play, uncomment to validate:
    # validate_ros2_topics([
    #     "/scan",
    #     "/imu/data",
    #     "/odom",
    #     "/camera/color/image_raw",
    #     "/camera/depth/image_raw",
    #     "/camera/color/camera_info",
    #     "/tf",
    # ])
