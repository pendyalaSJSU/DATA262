#!/usr/bin/env python3
"""
scripts/verify_install.py
==========================
Verify that all required dependencies are installed and the environment
is correctly configured for the Hospital Digital Twin exercise.

Run: python scripts/verify_install.py
"""

import sys
import subprocess
import importlib

PASS  = "\033[92m✓\033[0m"
FAIL  = "\033[91m✗\033[0m"
WARN  = "\033[93m⚠\033[0m"
INFO  = "\033[94m→\033[0m"

results = []

def check(name: str, fn) -> bool:
    try:
        fn()
        print(f"  {PASS} {name}")
        results.append((name, True))
        return True
    except Exception as e:
        print(f"  {FAIL} {name}: {e}")
        results.append((name, False))
        return False

def try_import(module: str, pip_name: str | None = None) -> None:
    try:
        importlib.import_module(module)
    except ImportError:
        pkg = pip_name or module
        raise ImportError(f"Install with: pip install {pkg}")

def check_command(cmd: list[str]) -> None:
    r = subprocess.run(cmd, capture_output=True, timeout=10)
    if r.returncode != 0:
        raise RuntimeError(r.stderr.decode()[:200])


print("\n══════════════════════════════════════════════")
print("  Hospital Digital Twin — Installation Check")
print("══════════════════════════════════════════════\n")

# ── Python version ─────────────────────────────────────────────────────────
print("Python environment:")
check("Python ≥ 3.10", lambda: (
    None if sys.version_info >= (3, 10)
    else (_ for _ in ()).throw(RuntimeError(f"Got {sys.version}"))
))

# ── Core Python packages ───────────────────────────────────────────────────
print("\nCore Python packages:")
pkgs = [
    ("pandas",    "pandas"),
    ("numpy",     "numpy"),
    ("scipy",     "scipy"),
    ("torch",     "torch"),
    ("pytest",    "pytest"),
]
for mod, pip in pkgs:
    check(mod, lambda m=mod, p=pip: try_import(m, p))

# ── ROS 2 ─────────────────────────────────────────────────────────────────
print("\nROS 2 Humble:")
check("rclpy",   lambda: try_import("rclpy"))
check("ros2 CLI", lambda: check_command(["ros2", "--version"]))
check("Nav2 simple commander",
      lambda: try_import("nav2_simple_commander",
                         "ros-humble-nav2-simple-commander"))

# ── Isaac Sim (optional — requires GPU) ────────────────────────────────────
print("\nNVIDIA Isaac Sim (GPU required):")
def check_isaac_sim():
    try:
        import omni.isaac.lab  # noqa
    except ImportError:
        raise RuntimeError(
            "omni.isaac.lab not found — activate isaaclab conda env: "
            "conda activate isaaclab"
        )

isaac_ok = check("omni.isaac.lab", check_isaac_sim)
if not isaac_ok:
    print(f"  {WARN} Isaac Sim not available — Tasks 1 and 4 require it.")
    print(f"  {INFO} Use NVIDIA LaunchPad (free): https://www.nvidia.com/en-us/launchpad/")

# ── GPU check ─────────────────────────────────────────────────────────────
print("\nGPU:")
def check_gpu():
    import torch
    if not torch.cuda.is_available():
        raise RuntimeError("No CUDA GPU detected. Isaac Sim requires NVIDIA GPU.")
    name = torch.cuda.get_device_name(0)
    mem_gb = torch.cuda.get_device_properties(0).total_memory / 1e9
    print(f"       → {name} ({mem_gb:.1f} GB VRAM)")

check("NVIDIA CUDA GPU", check_gpu)

# ── Data file ─────────────────────────────────────────────────────────────
print("\nData files:")
import os
check("mimic_vitals_sample.csv",
      lambda: (None if os.path.exists("data/mimic_vitals_sample.csv")
               else (_ for _ in ()).throw(FileNotFoundError("data/mimic_vitals_sample.csv not found"))))
check("patient_room_map.json",
      lambda: (None if os.path.exists("data/patient_room_map.json")
               else (_ for _ in ()).throw(FileNotFoundError("data/patient_room_map.json not found"))))
check("hospital_ward.usd",
      lambda: (None if os.path.exists("assets/hospital_ward.usd")
               else (_ for _ in ()).throw(FileNotFoundError("assets/hospital_ward.usd not found"))))

# ── Package imports ────────────────────────────────────────────────────────
print("\nHospital twin package:")
sys.path.insert(0, ".")
check("hospital_twin.news2_scorer",
      lambda: try_import("hospital_twin.news2_scorer"))

# ── Summary ────────────────────────────────────────────────────────────────
passed = sum(1 for _, ok in results if ok)
total  = len(results)
print(f"\n══════════════════════════════════════════════")
print(f"  Result: {passed}/{total} checks passed")
if passed == total:
    print(f"  {PASS} All checks passed! You're ready to start.")
elif passed >= total - 3:
    print(f"  {WARN} Minor issues — Tasks 1 & 4 may require Isaac Sim.")
else:
    print(f"  {FAIL} Several dependencies missing. Review output above.")
print("══════════════════════════════════════════════\n")

sys.exit(0 if passed >= total - 2 else 1)
