"""
hospital_twin/delivery_planner.py
===================================
Task 3: Priority-aware medication delivery planner using Nav2.

Subscribes to patient priority scores from MimicPublisher and dispatches
Nav2 navigation goals. Implements preemptive re-routing: if a higher-priority
patient alert fires mid-delivery, the current task is cancelled and the robot
diverts to the urgent patient first.

Key concepts illustrated
------------------------
- Closed-loop embodied reasoning: the robot's physical world (position, path)
  must be reconciled with the cyber world (patient priorities) continuously.
- Preemption requires *cancelling* a running action server goal — this is the
  embodied part: the body must actually stop before rerouting.

References
----------
nav2_simple_commander: https://github.com/ros-navigation/navigation2/tree/main/nav2_simple_commander
Nav2 Python API:        https://nav2.org/docs/commander_api/index.html
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy
from std_msgs.msg import Float32
from geometry_msgs.msg import PoseStamped

# nav2_simple_commander provides the high-level Python API for Nav2
# Install: sudo apt install ros-humble-nav2-simple-commander
try:
    from nav2_simple_commander.robot_navigator import BasicNavigator, TaskResult
except ImportError:
    raise ImportError(
        "nav2_simple_commander not found. "
        "Install: sudo apt install ros-humble-nav2-simple-commander"
    )


@dataclass
class DeliveryTask:
    """Represents one medication delivery to a patient room."""
    patient_id: str
    priority: float = 0.0
    pose: PoseStamped | None = None
    medication: str = "standard"

    def __lt__(self, other: "DeliveryTask") -> bool:
        """Higher priority → comes first in queue."""
        return self.priority > other.priority


class DeliveryPlanner(Node):
    """Priority-aware delivery planner with Nav2 preemptive re-routing.

    Parameters (ROS 2 parameters)
    ------------------------------
    room_map_path        : str   — path to patient_room_map.json
    preemption_threshold : float — priority delta to trigger preemption (default 3.0)
    patient_ids          : list  — patient IDs to monitor (default all 5)
    delivery_timeout_s   : float — seconds before a delivery is considered failed
    """

    PATIENT_IDS = ["p001", "p002", "p003", "p004", "p005"]

    def __init__(self) -> None:
        super().__init__("delivery_planner")

        # ── Parameters ────────────────────────────────────────────────────────
        self.declare_parameter("room_map_path", "data/patient_room_map.json")
        self.declare_parameter("preemption_threshold", 3.0)
        self.declare_parameter("delivery_timeout_s", 120.0)

        self.preempt_threshold = self.get_parameter("preemption_threshold").value
        self.timeout = self.get_parameter("delivery_timeout_s").value

        # ── Room map (patient_id → {x, y, yaw}) ──────────────────────────────
        map_path = self.get_parameter("room_map_path").value
        self.room_map: dict[str, dict] = self._load_room_map(map_path)

        # ── State ─────────────────────────────────────────────────────────────
        self.priorities: dict[str, float] = {pid: 0.0 for pid in self.PATIENT_IDS}
        self.pending_deliveries: list[DeliveryTask] = []
        self.current_task: DeliveryTask | None = None
        self.current_task_start: float = 0.0

        # ── Nav2 BasicNavigator ───────────────────────────────────────────────
        self.nav = BasicNavigator()

        # ── Priority subscribers (one per patient) ────────────────────────────
        qos = QoSProfile(reliability=ReliabilityPolicy.RELIABLE, depth=10)

        # TODO Task 3: Create priority subscribers for each patient.
        # For each pid in self.PATIENT_IDS, subscribe to /patient/{pid}/priority
        # using self._priority_callback as the callback.
        # HINT: Use a closure or functools.partial to bind pid to the callback.
        self.get_logger().warning("TODO Task 3: priority subscribers not yet created.")

        # ── Delivery queue timer ──────────────────────────────────────────────
        self.timer = self.create_timer(0.5, self._dispatch_loop)
        self.get_logger().info("DeliveryPlanner initialised. Waiting for Nav2...")
        self.nav.waitUntilNav2Active()
        self.get_logger().info("Nav2 is active. Ready for deliveries.")
        self._enqueue_initial_deliveries()

    # ── Callbacks ──────────────────────────────────────────────────────────────

    def _priority_callback(self, msg: Float32, patient_id: str) -> None:
        """Receive updated priority for a patient and check for preemption.

        TODO Task 3:
        1. Update self.priorities[patient_id] = msg.data
        2. If a task is currently running AND a higher-priority patient exists
           AND the priority difference exceeds self.preempt_threshold:
             a. Cancel the current Nav2 task (self.nav.cancelTask())
             b. Re-insert the interrupted task back into pending_deliveries
             c. Set self.current_task = None
        """
        raise NotImplementedError("TODO Task 3: implement _priority_callback")

    # ── Dispatch loop ──────────────────────────────────────────────────────────

    def _dispatch_loop(self) -> None:
        """Called every 0.5 s. Dispatch next task or monitor running task."""
        if self.current_task is not None:
            self._monitor_current_task()
            return

        if not self.pending_deliveries:
            return

        # Sort queue by priority (highest first) and take the top task
        self.pending_deliveries.sort()
        next_task = self.pending_deliveries.pop(0)
        self._start_delivery(next_task)

    def _start_delivery(self, task: DeliveryTask) -> None:
        """Begin a Nav2 navigation goal for the given delivery task.

        TODO Task 3:
        1. Build a PoseStamped goal from self.room_map[task.patient_id]
        2. Call self.nav.goToPose(goal)
        3. Set self.current_task = task and record start time
        4. Log the delivery start
        """
        if task.patient_id not in self.room_map:
            self.get_logger().error(
                f"No room mapping for patient {task.patient_id}. Skipping."
            )
            return

        # TODO Task 3: implement navigation goal dispatch
        self.get_logger().info(
            f"[TODO] Would deliver to patient {task.patient_id} "
            f"(priority={task.priority:.2f})"
        )

    def _monitor_current_task(self) -> None:
        """Check if the running Nav2 task has completed or timed out.

        TODO Task 3:
        1. If self.nav.isTaskComplete():
             - Get result = self.nav.getResult()
             - Log success or failure
             - Set self.current_task = None
        2. If elapsed time > self.timeout:
             - Cancel the task, log a timeout warning
             - Set self.current_task = None
        """
        # TODO Task 3: implement task completion / timeout monitoring
        pass

    # ── Helpers ────────────────────────────────────────────────────────────────

    def _build_pose(self, patient_id: str) -> PoseStamped:
        """Build a PoseStamped goal message from the room map.

        Parameters
        ----------
        patient_id : str — must be a key in self.room_map

        Returns
        -------
        PoseStamped with frame_id='map' and the room's (x, y, yaw)
        """
        import math
        from geometry_msgs.msg import Quaternion

        room = self.room_map[patient_id]
        goal = PoseStamped()
        goal.header.frame_id = "map"
        goal.header.stamp = self.get_clock().now().to_msg()
        goal.pose.position.x = float(room["x"])
        goal.pose.position.y = float(room["y"])
        goal.pose.position.z = 0.0

        yaw = float(room.get("yaw", 0.0))
        goal.pose.orientation = Quaternion(
            x=0.0,
            y=0.0,
            z=math.sin(yaw / 2),
            w=math.cos(yaw / 2),
        )
        return goal

    def _enqueue_initial_deliveries(self) -> None:
        """Add one delivery task per patient at simulation start."""
        for pid in self.PATIENT_IDS:
            task = DeliveryTask(
                patient_id=pid,
                priority=self.priorities.get(pid, 0.0),
                medication="morning_round",
            )
            self.pending_deliveries.append(task)
        self.get_logger().info(
            f"Enqueued {len(self.pending_deliveries)} initial delivery tasks."
        )

    def _load_room_map(self, path: str) -> dict[str, dict]:
        """Load patient room poses from a JSON file.

        Expected format:
        {
          "p001": {"x": 5.0, "y": 3.2, "yaw": 0.0},
          ...
        }
        """
        p = Path(path)
        if not p.exists():
            self.get_logger().warning(
                f"Room map not found at {path}. Using default positions."
            )
            # Fallback: evenly spaced positions along the corridor
            return {
                pid: {"x": 2.0 + i * 3.5, "y": 1.0, "yaw": 0.0}
                for i, pid in enumerate(self.PATIENT_IDS)
            }
        with open(p) as f:
            return json.load(f)


def main(args=None) -> None:
    rclpy.init(args=args)
    node = DeliveryPlanner()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
