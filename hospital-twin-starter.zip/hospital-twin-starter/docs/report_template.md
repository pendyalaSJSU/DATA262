# Technical Report: Hospital Digital Twin
**Course:** Embodied AI | **Student:** [Your Name] | **Date:** [Date]

---

## Abstract (150 words max)

_Briefly describe what you built, what it does, and your most significant finding._

---

## 1. What makes this system "embodied"? (400 words)

Address all three questions:

**1a.** How does the robot's physical body (sensors, actuators, mass, geometry) constrain and
shape its intelligence? Could the same intelligence exist without the body? Why or why not?

**1b.** How does the MIMIC-IV data loop close the sensing–reasoning–action cycle? Draw a
diagram of the complete embodied loop in your system.

**1c.** Compare your system to a purely symbolic planner (e.g., a rule-based priority queue
with no physics). What can your embodied system do that a symbolic system cannot?

---

## 2. Physical fidelity and policy robustness (400 words)

**2a.** What specific Isaac Sim physics features (collision geometry, inertia, lidar noise
modelling, joint friction) most affected your RL policy's behaviour? Provide evidence
from your training curves or scenario recordings.

**2b.** Describe one experiment where increasing physics fidelity improved policy robustness
and one where it slowed training. How did you resolve the tradeoff?

**2c.** Discuss sim-to-real transfer: what would break if you deployed your trained policy on
a physical TurtleBot4 in a real hospital corridor? Be specific (domain gap, sensor noise,
latency, unknown objects, etc.).

---

## 3. Failure modes (300 words, 2 specific modes)

Describe exactly two failure modes you observed during development or the scenario recording.
For each:

- **What happened:** (specific observable behaviour)
- **Root cause:** (trace back to the embodied AI system — sensor, model, reward, physics)
- **Mitigation:** (what you tried or would try)

**Failure mode 1:**

**Failure mode 2:**

---

## 4. Results summary

| Metric | Value |
|---|---|
| RL policy goal-reach rate (test) | % |
| RL vs Nav2 DWB planner (obstacle course) | |
| Mean preemption latency (Task 3) | s |
| MIMIC telemetry publish rate | Hz |
| System integration latency (sensor → Nav2 goal) | ms |

---

## 5. References

_Cite at minimum: MIMIC-IV paper, Isaac Lab paper, NEWS2 specification, and two academic
papers on embodied AI or robot learning._

---

_Word count (sections 1–3 only): _____ / 1500_
