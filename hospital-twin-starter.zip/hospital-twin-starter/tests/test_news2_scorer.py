"""
tests/test_news2_scorer.py
===========================
Unit tests for the NEWS2 scoring implementation.

Run: pytest tests/test_news2_scorer.py -v

These tests will fail until you complete Task 2.
Reference values validated against the RCP NEWS2 specification:
https://www.rcplondon.ac.uk/projects/outputs/national-early-warning-score-news-2
"""

import pytest
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from hospital_twin.news2_scorer import (
    news2_score,
    ewma_priority,
    _score_resp_rate,
    _score_spo2,
    _score_systolic_bp,
    _score_heart_rate,
    _score_temperature,
    _score_consciousness,
    priority_to_ros_color,
)


# ── Respiratory rate ──────────────────────────────────────────────────────────

class TestRespRate:
    def test_rr_critical_low(self):   assert _score_resp_rate(6) == 3
    def test_rr_borderline_low(self): assert _score_resp_rate(8) == 3
    def test_rr_low(self):            assert _score_resp_rate(9) == 1
    def test_rr_low_boundary(self):   assert _score_resp_rate(11) == 1
    def test_rr_normal(self):         assert _score_resp_rate(12) == 0
    def test_rr_normal_high(self):    assert _score_resp_rate(20) == 0
    def test_rr_elevated(self):       assert _score_resp_rate(21) == 2
    def test_rr_elevated_high(self):  assert _score_resp_rate(24) == 2
    def test_rr_critical_high(self):  assert _score_resp_rate(25) == 3
    def test_rr_very_high(self):      assert _score_resp_rate(35) == 3


# ── SpO2 ──────────────────────────────────────────────────────────────────────

class TestSpO2:
    def test_spo2_critical(self):     assert _score_spo2(88) == 3
    def test_spo2_low(self):          assert _score_spo2(92) == 2
    def test_spo2_borderline(self):   assert _score_spo2(93) == 2
    def test_spo2_slightly_low(self): assert _score_spo2(94) == 1
    def test_spo2_normal(self):       assert _score_spo2(96) == 0
    def test_spo2_high_normal(self):  assert _score_spo2(99) == 0

    # Scale 2 (supplemental O2)
    def test_spo2_scale2_target(self):    assert _score_spo2(90, on_oxygen=True) == 0
    def test_spo2_scale2_above_target(self): assert _score_spo2(95, on_oxygen=True) == 2


# ── Heart rate ────────────────────────────────────────────────────────────────

class TestHeartRate:
    def test_hr_critical_low(self):   assert _score_heart_rate(35) == 3
    def test_hr_low(self):            assert _score_heart_rate(45) == 1
    def test_hr_normal_low(self):     assert _score_heart_rate(51) == 0
    def test_hr_normal(self):         assert _score_heart_rate(72) == 0
    def test_hr_normal_high(self):    assert _score_heart_rate(90) == 0
    def test_hr_elevated(self):       assert _score_heart_rate(100) == 1
    def test_hr_high(self):           assert _score_heart_rate(120) == 2
    def test_hr_critical_high(self):  assert _score_heart_rate(135) == 3


# ── Temperature ───────────────────────────────────────────────────────────────

class TestTemperature:
    def test_temp_hypothermia(self):  assert _score_temperature(34.5) == 3
    def test_temp_subnormal(self):    assert _score_temperature(35.5) == 1
    def test_temp_normal_low(self):   assert _score_temperature(36.2) == 0
    def test_temp_normal(self):       assert _score_temperature(37.0) == 0
    def test_temp_normal_high(self):  assert _score_temperature(38.0) == 0
    def test_temp_febrile(self):      assert _score_temperature(38.5) == 1
    def test_temp_high_fever(self):   assert _score_temperature(39.5) == 2


# ── Consciousness ─────────────────────────────────────────────────────────────

class TestConsciousness:
    def test_avpu_alert(self):       assert _score_consciousness("A") == 0
    def test_avpu_confusion(self):   assert _score_consciousness("C") == 3
    def test_avpu_voice(self):       assert _score_consciousness("V") == 3
    def test_avpu_pain(self):        assert _score_consciousness("P") == 3
    def test_avpu_unresponsive(self): assert _score_consciousness("U") == 3
    def test_avpu_invalid(self):
        with pytest.raises(ValueError):
            _score_consciousness("X")


# ── Aggregate NEWS2 ───────────────────────────────────────────────────────────

class TestNEWS2Score:
    def test_healthy_patient(self):
        score, risk = news2_score(
            heart_rate=72, resp_rate=14, spo2=98,
            systolic_bp=130, temperature=37.0, avpu="A"
        )
        assert score == 0
        assert risk == "low"

    def test_deteriorating_patient(self):
        """Patient with elevated RR, low SpO2, tachycardia → high risk."""
        score, risk = news2_score(
            heart_rate=120, resp_rate=26, spo2=90,
            systolic_bp=95, temperature=38.6, avpu="C"
        )
        assert score >= 9
        assert risk == "high"

    def test_medium_risk_single_3(self):
        """A single parameter scoring 3 → medium risk even if total < 5."""
        score, risk = news2_score(
            heart_rate=72, resp_rate=8,   # RR=8 → score 3
            spo2=98, systolic_bp=130, temperature=37.0, avpu="A"
        )
        assert score == 3
        assert risk == "medium"  # single-param 3 rule

    def test_missing_values(self):
        """Sentinel -1.0 values should not crash, treated as 0."""
        score, risk = news2_score(
            heart_rate=-1.0, resp_rate=16, spo2=97,
            systolic_bp=120, temperature=-1.0
        )
        assert isinstance(score, int)
        assert risk in ("low", "medium", "high")


# ── EWMA priority ─────────────────────────────────────────────────────────────

class TestEWMAPriority:
    def test_empty(self):
        assert ewma_priority([]) == 0.0

    def test_single(self):
        assert ewma_priority([5.0]) == pytest.approx(5.0)

    def test_stable_stable(self):
        scores = [2, 2, 2, 2, 2]
        assert ewma_priority(scores) == pytest.approx(2.0, abs=0.01)

    def test_rising_trend(self):
        scores = [0, 1, 2, 4, 7]
        priority = ewma_priority(scores, alpha=0.3)
        # Should be higher than the mean (4.0) due to recent weight
        assert priority > 4.0

    def test_invalid_alpha(self):
        with pytest.raises(ValueError):
            ewma_priority([1, 2, 3], alpha=0.0)


# ── ROS color mapping ─────────────────────────────────────────────────────────

class TestPriorityColor:
    def test_low_priority_is_green(self):
        r, g, b, a = priority_to_ros_color(2.0)
        assert g > r and g > b   # green dominant

    def test_high_priority_is_red(self):
        r, g, b, a = priority_to_ros_color(8.0)
        assert r > g and r > b   # red dominant

    def test_alpha_always_one(self):
        for p in [0.0, 3.0, 5.0, 7.0, 10.0]:
            _, _, _, a = priority_to_ros_color(p)
            assert a == pytest.approx(1.0)
